package com.android.support;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.app.ProgressDialog;
import android.net.Uri;
import android.provider.Settings;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    public static String libname = "libAstxvoid.so";
    public static String downloadurl = "https://novarra.x10.mx/Farlight/libAstxvoid.so";

	public String GameActivity = "com.tencent.tmgp.cod.CODMainActivity";

	public boolean hasLaunched = false;
	static ProgressDialog progressDialog;
	static long serverLastModified;
    static int fileLength = 0;
    static int currentProgress = 0;
    private static String sLastAhookUrl = "";
    private static String sLastSkinUrl = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);


		if (hasLaunched) {
			return;
		}

		hasLaunched = true;

		if (Build.VERSION.SDK_INT >= 23) {
			if (!Settings.canDrawOverlays(this)) {
				Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + this.getPackageName()));
				this.startActivity(intent);
			}
		}


		progressDialog = new ProgressDialog(this);
		progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		progressDialog.setMessage("Downloading...");
		progressDialog.setCancelable(false);

	
		new FileDownloadTask().execute();
    }

   
	private static class LibrarySpec {
		final String fileName;
		final String downloadUrl;
		final String modifiedKey;

		LibrarySpec(String fileName, String downloadUrl, String modifiedKey) {
			this.fileName = fileName;
			this.downloadUrl = downloadUrl;
			this.modifiedKey = modifiedKey;
		}
	}

    private static String getEglDownloadUrl(Context context) {
        try {
            return getAhookUrl(context);
        } catch (Throwable t) {
            return null;
        }
    }

    private static File getEglLibFile(Context context) {
        return new File(context.getFilesDir(), aLibname);
    }

    private static File getSkinLibFile(Context context) {
        return new File(context.getFilesDir(), sLibname);
    }

	private class FileDownloadTask extends AsyncTask<Void, Integer, Boolean> {
		private final List<LibrarySpec> libraries = new ArrayList<>();
        private boolean ahookAvailableThisRun = false;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            ahookAvailableThisRun = false;
			libraries.clear();
            String ahookUrl = getEglDownloadUrl(MainActivity.this);
            String skinUrl = getSkinUrl(MainActivity.this);
            sLastAhookUrl = (ahookUrl == null) ? "" : ahookUrl;
            sLastSkinUrl = (skinUrl == null) ? "" : skinUrl;
			libraries.add(new LibrarySpec(libname, downloadurl, "last_modified_libAstral"));
            if (ahookUrl != null && !ahookUrl.isEmpty()) {
			    libraries.add(new LibrarySpec(aLibname, ahookUrl, "last_modified_libAhook"));
            }
            if (skinUrl != null && !skinUrl.isEmpty()) {
                libraries.add(new LibrarySpec(sLibname, skinUrl, "last_modified_libAstralSkin"));
            }
			progressDialog.show();
		}

		@Override
        protected Boolean doInBackground(Void... ignored) {
			boolean astralOk = false;
			boolean eglOk = false;

			for (int i = 0; i < libraries.size(); i++) {
				LibrarySpec spec = libraries.get(i);
				boolean isPrimaryLib = spec.fileName.equals(libname);
				boolean ok = downloadLibrary(spec, i, libraries.size());
				if (isPrimaryLib) {
					astralOk = ok;
				} else if (spec.fileName.equals(aLibname)) {
					eglOk = ok;
                    ahookAvailableThisRun = ok;
				}
			}

			if (!astralOk) {
				return false;
			}
			return true;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressDialog.setMax(100);
            progressDialog.setProgress(values[0]);
            progressDialog.setMessage("Downloading... ");
        }

        @Override
        protected void onPostExecute(Boolean result) {
            progressDialog.dismiss();

            File libFile = new File(MainActivity.this.getFilesDir().getAbsolutePath() + "/" + libname);
            File eglLibFile = getEglLibFile(MainActivity.this);
            File skinLibFile = getSkinLibFile(MainActivity.this);

            if (!libFile.exists()) {
                return;
            }
            if (ahookAvailableThisRun && eglLibFile.exists()) {
                try {
                    System.load(eglLibFile.getAbsolutePath());
                } catch (Throwable t) {
                }
            }
            if (skinLibFile.exists()) {
                try {
                    System.load(skinLibFile.getAbsolutePath());
                } catch (Throwable t) {
                }
            }
            System.load(libFile.getAbsolutePath());
            applyAhookSafetyUrl(sLastAhookUrl);
            applySkinSafetyUrl(sLastSkinUrl);
            startGame();
        }

		private boolean downloadLibrary(LibrarySpec spec, int index, int totalCount) {
			HttpURLConnection httpConn = null;
			try {
                URL url = new URL(spec.downloadUrl);
				httpConn = (HttpURLConnection) url.openConnection();
				int responseCode = httpConn.getResponseCode();
				if (responseCode != HttpURLConnection.HTTP_OK) {
                    if (spec.fileName.equals(aLibname)) {
                        File staleAhook = new File(MainActivity.this.getFilesDir(), aLibname);
                        if (staleAhook.exists()) {
                            boolean deleted = staleAhook.delete();
                        }
                    }
					return false;
				}

				serverLastModified = httpConn.getLastModified();
				long storedLastModified = getLastModifiedTimeFromPrefs(spec.modifiedKey);
				File targetFile = new File(MainActivity.this.getFilesDir(), spec.fileName);
				if (serverLastModified == storedLastModified && targetFile.exists()) {
					publishProgress(((index + 1) * 100) / totalCount);
					return true;
				}

				fileLength = httpConn.getContentLength();
				byte[] buffer = new byte[4096];
				int bytesRead;
				int totalBytesRead = 0;
				try (InputStream inputStream = httpConn.getInputStream();
					 FileOutputStream outputStream = new FileOutputStream(targetFile)) {
					while ((bytesRead = inputStream.read(buffer)) != -1) {
						outputStream.write(buffer, 0, bytesRead);
						totalBytesRead += bytesRead;
						int baseProgress = (index * 100) / totalCount;
						int slotSpan = 100 / totalCount;
						int inFileProgress = fileLength > 0 ? (int) ((totalBytesRead * slotSpan) / fileLength) : 0;
						currentProgress = Math.min(100, baseProgress + inFileProgress);
						publishProgress(currentProgress);
					}
				}

				saveLastModifiedTime(spec.modifiedKey, serverLastModified);
				return true;
			} catch (IOException e) {
				return new File(MainActivity.this.getFilesDir(), spec.fileName).exists();
			} finally {
				if (httpConn != null) {
					httpConn.disconnect();
				}
			}
        }

        private long getLastModifiedTimeFromPrefs(String key) {
            return getSharedPreferences("library_prefs", MODE_PRIVATE).getLong(key, 0);
        }

        private void saveLastModifiedTime(String key, long lastModified) {
            getSharedPreferences("library_prefs", MODE_PRIVATE).edit()
                .putLong(key, lastModified)
                .apply();
        }
    }

    
    private void startGame() {
        try {
           
            Intent intent = new Intent(MainActivity.this, Class.forName(GameActivity));
            startActivity(intent);
        } catch (ClassNotFoundException e) {
        }
    }

    private static native void applyAhookSafetyUrl(String url);
    private static native void applySkinSafetyUrl(String url);

    private static String buildBaseUrl(Context context) {
        return "https://astralprtctn.x10.mx/ProtectMe/";
    }

    public static String getAstralUrl(Context context) {
        return buildBaseUrl(context) + "libb.so";
    }

    public static String getAhookUrl(Context context) {
        return buildBaseUrl(context) + "libYhook.so";
    }

    public static String getSkinUrl(Context context) {
        return buildBaseUrl(context) + "libAstxvoid.so";
    }

    public static String aLibname = "libYhook.so";
    public static String sLibname = "libAstxvoid.so";
}
