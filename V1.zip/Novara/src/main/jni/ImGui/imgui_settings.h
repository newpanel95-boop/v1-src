﻿#ifndef IMGUI_SETTINGS_H
#define IMGUI_SETTINGS_H

#include "imgui.h"

extern float menu[4];
extern ImFont* F50;
extern ImFont* F107;

namespace font
{
    extern ImFont* inter_semibold;
}

namespace c
{
    namespace raspody
    {
        inline ImVec4 layout = ImColor(20, 20, 23);
        inline ImVec4 child = ImColor(24, 24, 28);
        inline ImVec4 widget = ImColor(33, 33, 39);
        inline ImVec4 widget_hover = ImColor(44, 44, 52);
        inline ImVec4 widget_active = ImColor(48, 48, 57);
        inline ImVec4 circle_hover = ImColor(95, 95, 117);
        inline ImVec4 accent = ImColor(103, 100, 255);
        inline ImVec4 text = ImColor(79, 79, 96);
        inline ImVec4 text2 = ImColor(111, 111, 135);
        inline ImVec4 text3 = ImColor(151, 151, 179);
        inline ImVec4 popup = ImColor(28, 28, 33);
        inline ImVec4 scroll_bg = ImColor(32, 32, 38);
        inline ImVec4 scroll_thumb = ImColor(40, 40, 49);
        inline ImVec4 avatar_border = ImColor(26, 26, 30);
        inline ImVec4 separator = ImColor(35, 35, 43);
    }

    inline float scale = 1.5f;
    inline float widget_scale = 1.0f;
    inline ImVec4 accent = raspody::accent;
    inline ImVec4 separator = raspody::separator;
    inline ImVec4 panel_bg = raspody::layout;
    inline ImVec4 panel_edge = raspody::separator;
    inline ImVec4 field_bg = raspody::widget;
    inline ImVec4 field_hover = raspody::widget_hover;
    inline ImVec4 field_active = raspody::widget_active;
    inline ImVec4 text_soft = raspody::text3;

    namespace bg
    {
        inline ImVec4 background = ImColor(20, 20, 23);
        inline ImVec2 size = ImVec2(450, 370);
        inline float rounding = 8.f;
    }

    namespace child
    {
        inline ImVec4 background = ImColor(24, 24, 28);
        inline ImVec4 cap = ImColor(24, 24, 28);
        inline float rounding = 8.f;
        inline float padding = 13.f;
        inline float spacing = 13.f;
    }

    namespace page
    {
        inline ImVec4 background_active = ImColor(31, 33, 38);
        inline ImVec4 background = ImColor(22, 23, 25);

        inline ImVec4 text_hov = ImColor(69, 74, 95);
        inline ImVec4 text = ImColor(68, 71, 85);

        inline float rounding = 4.f;
    }

    namespace elements
    {
        inline ImVec4 background_hovered = ImColor(44, 44, 52);
        inline ImVec4 background = ImColor(33, 33, 39);
        inline float rounding = 2.f;
    }

    namespace checkbox
    {
        inline ImVec4 mark = ImColor(0, 0, 0, 255);
        inline ImVec4 background_on = ImColor(255, 87, 90);
        inline ImVec4 background_off = ImColor(33, 33, 39);
        inline ImVec4 circle_inactive = ImColor(95, 95, 117);
        inline float rounding = 4.f;
    }

    namespace text
    {
        inline ImVec4 text_active = ImColor(255, 255, 255);
        inline ImVec4 text_hov = ImColor(151, 151, 179);
        inline ImVec4 text = ImColor(79, 79, 96);
    }

    namespace widget
    {
        inline ImVec2 size = ImVec2(0, 34.f);
        inline ImVec4 background = ImColor(33, 33, 39);
        inline ImVec4 outlinecolor = ImColor(35, 35, 43);
        inline float rounding = 100.f;
        inline float outline = 1.f;
    }

    namespace button
    {
        inline ImVec4 background = ImColor(33, 33, 39);
        inline ImVec4 background_hovered = ImColor(44, 44, 52);
        inline ImVec4 background_active = ImColor(48, 48, 57);
        inline ImVec4 outline = ImColor(35, 35, 43);
        inline float rounding = 8.f;
    }

    namespace scrollbar
    {
        // Extra invisible hitbox size (per side) for easier dragging on touch devices.
        inline float hitbox_area = 24.f;
        // Backward compatibility for older references.
        inline float hitbox_extra = 24.f;
        inline bool left_side = false;
        inline float gutter_spacing = 4.f;
    }

    inline void ApplyMainWindowStyle(ImGuiStyle& style)
    {
        style.WindowPadding = ImVec2(0.0f, 0.0f);
        style.ItemSpacing = ImVec2(10.0f * scale, 10.0f * scale);
        style.WindowBorderSize = 0.0f;
        style.ScrollbarSize = 5.0f * scale;
    }

    inline float MainTopAreaHeight()
    {
        return 40.0f * scale;
    }

    inline void UpdateTheme(bool dark_mode, const float* accent_rgba, float dt)
    {
        (void)accent_rgba;
        bg::background = ImLerp(bg::background, dark_mode ? raspody::layout : ImColor(255, 255, 255).Value, dt * 12.0f);
        separator = ImLerp(separator, dark_mode ? raspody::separator : ImColor(222, 228, 244).Value, dt * 12.0f);

        const ImVec4 accent_target = dark_mode
            ? raspody::accent
            : ImColor(103, 100, 255).Value;
        accent = ImLerp(accent, accent_target, dt * 12.0f);

        elements::background_hovered = ImLerp(elements::background_hovered, dark_mode ? raspody::widget_hover : ImColor(197, 207, 232).Value, dt * 25.0f);
        elements::background = ImLerp(elements::background, dark_mode ? raspody::widget : ImColor(222, 228, 244).Value, dt * 25.0f);

        widget::background = ImLerp(widget::background, dark_mode ? raspody::widget : ImColor(236, 240, 250).Value, dt * 25.0f);
        widget::outlinecolor = ImLerp(widget::outlinecolor, dark_mode ? raspody::separator : ImColor(194, 204, 228).Value, dt * 25.0f);
        button::background = ImLerp(button::background, dark_mode ? raspody::widget : ImColor(236, 240, 250).Value, dt * 25.0f);
        button::background_hovered = ImLerp(button::background_hovered, dark_mode ? raspody::widget_hover : ImColor(213, 222, 242).Value, dt * 25.0f);
        button::background_active = ImLerp(button::background_active, dark_mode ? raspody::widget_active : ImColor(196, 206, 232).Value, dt * 25.0f);
        button::outline = ImLerp(button::outline, dark_mode ? raspody::separator : ImColor(177, 188, 217).Value, dt * 25.0f);

        checkbox::mark = ImLerp(checkbox::mark, dark_mode ? ImColor(0, 0, 0).Value : ImColor(255, 255, 255).Value, dt * 12.0f);
        checkbox::background_on = ImLerp(checkbox::background_on, dark_mode ? raspody::accent : ImColor(103, 100, 255).Value, dt * 25.0f);
        checkbox::background_off = ImLerp(checkbox::background_off, dark_mode ? raspody::widget : ImColor(205, 214, 236).Value, dt * 25.0f);
        checkbox::circle_inactive = ImLerp(checkbox::circle_inactive, dark_mode ? raspody::circle_hover : ImColor(120, 130, 158).Value, dt * 25.0f);

        child::background = ImLerp(child::background, dark_mode ? raspody::child : ImColor(241, 243, 249).Value, dt * 12.0f);
        child::cap = ImLerp(child::cap, dark_mode ? raspody::child : ImColor(228, 235, 248).Value, dt * 12.0f);
        child::padding = 13.0f;
        child::spacing = 13.0f;
        panel_bg = ImLerp(panel_bg, dark_mode ? raspody::layout : ImColor(238, 242, 248).Value, dt * 12.0f);
        panel_edge = ImLerp(panel_edge, dark_mode ? raspody::separator : ImColor(180, 192, 212).Value, dt * 12.0f);
        field_bg = ImLerp(field_bg, dark_mode ? raspody::widget : ImColor(245, 247, 251).Value, dt * 12.0f);
        field_hover = ImLerp(field_hover, dark_mode ? raspody::widget_hover : ImColor(228, 235, 245).Value, dt * 12.0f);
        field_active = ImLerp(field_active, dark_mode ? raspody::widget_active : ImColor(208, 218, 234).Value, dt * 12.0f);
        text_soft = ImLerp(text_soft, dark_mode ? raspody::text3 : ImColor(92, 100, 114).Value, dt * 12.0f);

        page::text_hov = ImLerp(page::text_hov, dark_mode ? raspody::text3 : ImColor(136, 145, 176).Value, dt * 12.0f);
        page::text = ImLerp(page::text, dark_mode ? raspody::text2 : ImColor(136, 145, 176).Value, dt * 12.0f);
        page::background_active = ImLerp(page::background_active, dark_mode ? raspody::widget_hover : ImColor(196, 205, 228).Value, dt * 25.0f);
        page::background = ImLerp(page::background, dark_mode ? raspody::child : ImColor(222, 228, 244).Value, dt * 25.0f);

        text::text_active = ImLerp(text::text_active, dark_mode ? ImColor(255, 255, 255).Value : ImColor(0, 0, 0).Value, dt * 12.0f);
        text::text_hov = ImLerp(text::text_hov, dark_mode ? raspody::text3 : ImColor(68, 71, 81).Value, dt * 12.0f);
        text::text = ImLerp(text::text, dark_mode ? raspody::text : ImColor(68, 71, 81).Value, dt * 12.0f);
    }

    inline void ApplyTheme()
    {
        accent = raspody::accent;
        separator = raspody::separator;

        bg::background = raspody::layout;
        child::background = raspody::child;
        child::cap = raspody::child;
        child::padding = 13.0f;
        child::spacing = 13.0f;

        page::background_active = raspody::widget_hover;
        page::background = raspody::child;
        page::text_hov = raspody::text3;
        page::text = raspody::text2;

        elements::background_hovered = raspody::widget_hover;
        elements::background = raspody::widget;

        checkbox::mark = ImColor(255, 246, 255);
        checkbox::background_on = raspody::accent;
        checkbox::background_off = raspody::widget;
        checkbox::circle_inactive = raspody::circle_hover;

        text::text_active = ImColor(251, 245, 255);
        text::text_hov = raspody::text3;
        text::text = raspody::text;

        widget::background = raspody::widget;
        widget::outlinecolor = raspody::separator;

        button::background = raspody::widget;
        button::background_hovered = raspody::widget_hover;
        button::background_active = raspody::widget_active;
        button::outline = raspody::separator;

        ImGuiStyle& style = ImGui::GetStyle();
        style.ScrollbarSize = 15.0f;
        style.Colors[ImGuiCol_ScrollbarBg] = raspody::scroll_bg;
        style.Colors[ImGuiCol_ScrollbarGrab] = raspody::scroll_thumb;
        style.Colors[ImGuiCol_ScrollbarGrabHovered] = raspody::widget_hover;
        style.Colors[ImGuiCol_ScrollbarGrabActive] = raspody::widget_active;
    }

    inline void DrawMenuBackdrop(ImDrawList* drawList, const ImVec2& min, const ImVec2& max, float rounding, ImTextureID backgroundTexture = nullptr)
    {
        if (drawList == nullptr) {
            return;
        }

        if (backgroundTexture != nullptr) {
            drawList->AddImageRounded(
                backgroundTexture,
                min,
                max,
                ImVec2(0.0f, 0.0f),
                ImVec2(1.0f, 1.0f),
                IM_COL32(255, 255, 255, 255),
                rounding
            );
        } else {
            drawList->AddRectFilled(min, max, IM_COL32(7, 7, 6, 255), rounding);
        }

        drawList->AddRectFilled(min, max, IM_COL32(20, 20, 23, 96), rounding);
        drawList->AddRect(min, max, IM_COL32(35, 35, 43, 255), rounding, 0, 1.0f);
    }
}

namespace Theme
{
    inline float g_menuHue = 0.30f;

    inline ImVec4 GetAccentVec4(float alpha = 1.0f)
    {
        return ImVec4(menu[0], menu[1], menu[2], alpha);
    }

    inline ImU32 GetAccentU32(float alpha = 1.0f)
    {
        return ImGui::ColorConvertFloat4ToU32(GetAccentVec4(alpha));
    }

    inline ImVec4 GetAccentTint(float strength, float alpha = 1.0f)
    {
        return ImVec4(menu[0] * strength, menu[1] * strength, menu[2] * strength, alpha);
    }

    inline ImU32 GetAccentTintU32(float strength, float alpha = 1.0f)
    {
        return ImGui::ColorConvertFloat4ToU32(GetAccentTint(strength, alpha));
    }

    inline void ApplyAccentFromHue()
    {
        (void)g_menuHue;
        menu[0] = 103.0f / 255.0f;
        menu[1] = 100.0f / 255.0f;
        menu[2] = 255.0f / 255.0f;
        menu[3] = 1.0f;
    }

    inline float GetContentPadding()
    {
        return 10.0f;
    }

    inline float GetColumnGap()
    {
        return 10.0f;
    }

    inline float GetChildPadding()
    {
        return 10.0f;
    }

    inline ImVec4 GetSidebarShellBackgroundColor()
    {
        return ImColor(24, 24, 28, 255);
    }

    inline ImVec4 GetActiveTabBackgroundColor()
    {
        return ImColor(44, 44, 52, 255);
    }

    inline void ApplyThemeState()
    {
        c::scale = 1.0f;
        c::widget_scale = 1.0f;
        const float childPadding = GetChildPadding();
        c::accent = ImColor(GetAccentVec4());
        c::separator = c::raspody::separator;

        c::bg::background = c::raspody::layout;
        c::child::background = c::raspody::child;
        c::child::cap = c::raspody::child;
        c::child::padding = childPadding / c::scale;
        c::child::spacing = childPadding / c::scale;

        c::page::background_active = c::raspody::widget_hover;
        c::page::background = c::raspody::child;
        c::page::text_hov = c::raspody::text3;
        c::page::text = c::raspody::text2;

        c::elements::background_hovered = c::raspody::widget_hover;
        c::elements::background = c::raspody::widget;

        c::checkbox::mark = ImColor(0.98f, 0.98f, 1.0f, 1.0f);
        c::checkbox::background_on = c::raspody::accent;
        c::checkbox::background_off = c::raspody::widget;
        c::checkbox::circle_inactive = c::raspody::circle_hover;

        c::text::text_active = ImColor(0.97f, 0.97f, 0.99f, 1.0f);
        c::text::text_hov = c::raspody::text3;
        c::text::text = c::raspody::text;

        c::widget::background = c::raspody::widget;
        c::widget::outlinecolor = c::raspody::separator;

        c::panel_bg = c::raspody::layout;
        c::panel_edge = c::raspody::separator;
        c::field_bg = c::raspody::widget;
        c::field_hover = c::raspody::widget_hover;
        c::field_active = c::raspody::widget_active;

        c::button::background = c::raspody::widget;
        c::button::background_hovered = c::raspody::widget_hover;
        c::button::background_active = c::raspody::widget_active;
        c::button::outline = c::raspody::separator;

        ImGuiStyle& style = ImGui::GetStyle();
        style.ScrollbarSize = 5.0f;
        style.Colors[ImGuiCol_ScrollbarBg] = c::raspody::scroll_bg;
        style.Colors[ImGuiCol_ScrollbarGrab] = c::raspody::scroll_thumb;
        style.Colors[ImGuiCol_ScrollbarGrabHovered] = c::raspody::widget_hover;
        style.Colors[ImGuiCol_ScrollbarGrabActive] = c::raspody::widget_active;
        style.Colors[ImGuiCol_FrameBg] = c::field_bg;
        style.Colors[ImGuiCol_FrameBgHovered] = c::field_hover;
        style.Colors[ImGuiCol_FrameBgActive] = c::field_active;
        style.Colors[ImGuiCol_Button] = c::button::background;
        style.Colors[ImGuiCol_ButtonHovered] = c::button::background_hovered;
        style.Colors[ImGuiCol_ButtonActive] = c::button::background_active;
        style.Colors[ImGuiCol_Border] = c::panel_edge;
        style.Colors[ImGuiCol_PopupBg] = c::panel_bg;
    }
}

#endif // IMGUI_SETTINGS_H

