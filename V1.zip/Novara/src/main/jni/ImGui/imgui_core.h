#pragma once

#include <jni.h>
#include <string>
#include <ctime>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <cmath>
#include <atomic>
#include <chrono>
#include <thread>
#include <sys/sysinfo.h>
#include <curl/curl.h>

#include "../System/UI/TextureLoader.h"

extern JavaVM* jvm;
extern float menu[4];
extern ImFont* F50;
extern ImFont* F107;

namespace font {
    extern ImFont* inter_semibold;
    extern ImFont* auto_techno;
    extern ImFont* angas_ultra;
}

namespace runtime_preview_menu {

struct Texture {
    GLuint id = 0;
};

struct StateRefs {
    bool &dark;
    float &tabAlpha;
    float &tabAdd;
    int &page;
    int &activeTab;
    bool &windowCollapsed;
    bool &isMenuVisible;
    double &collapseBarLastActiveTime;
    float &collapseBarOpacityAnim;
    float &collapseBarPressAnim;
};

static bool g_popupFocusVisible = false;
static ImVec2 g_popupFocusMin(0.0f, 0.0f);
static ImVec2 g_popupFocusMax(0.0f, 0.0f);

inline void EnsureTexture(Texture &texture, const unsigned char *bytes, int size)
{
    if (texture.id != 0) {
        return;
    }
    texture.id = LoadTextureFromMemory(bytes, size);
}

inline void EnsureTexturesLoaded()
{
}

inline void ResetPopupFocusWindow()
{
    g_popupFocusVisible = false;
    g_popupFocusMin = ImVec2(0.0f, 0.0f);
    g_popupFocusMax = ImVec2(0.0f, 0.0f);
}

inline void RegisterPopupFocusWindow()
{
    const ImVec2 min = ImGui::GetWindowPos();
    const ImVec2 windowSize = ImGui::GetWindowSize();
    const ImVec2 max(min.x + windowSize.x, min.y + windowSize.y);
    if (!g_popupFocusVisible) {
        g_popupFocusVisible = true;
        g_popupFocusMin = min;
        g_popupFocusMax = max;
        return;
    }

    g_popupFocusMin.x = ImMin(g_popupFocusMin.x, min.x);
    g_popupFocusMin.y = ImMin(g_popupFocusMin.y, min.y);
    g_popupFocusMax.x = ImMax(g_popupFocusMax.x, max.x);
    g_popupFocusMax.y = ImMax(g_popupFocusMax.y, max.y);
}

inline void IconCenter(ImDrawList *draw, ImFont *font, float size, const ImVec2 &center, ImU32 color, const char *icon)
{
    if (!draw || !font || !icon || !icon[0])
        return;
    const ImVec2 text = font->CalcTextSizeA(size, FLT_MAX, 0.0f, icon);
    draw->AddText(font, size, center - text * 0.5f, color, icon);
}

inline void DrawPopupBackdropFocusLayer(ImDrawList *drawList)
{
    if (drawList == nullptr || !g_popupFocusVisible) {
        return;
    }

    drawList->PushClipRectFullScreen();
    const ImVec2 viewportMax = ImGui::GetIO().DisplaySize;
    const ImVec2 holeMin(
        ImClamp(g_popupFocusMin.x, 0.0f, viewportMax.x),
        ImClamp(g_popupFocusMin.y, 0.0f, viewportMax.y)
    );
    const ImVec2 holeMax(
        ImClamp(g_popupFocusMax.x, 0.0f, viewportMax.x),
        ImClamp(g_popupFocusMax.y, 0.0f, viewportMax.y)
    );
    const ImU32 dimColor = IM_COL32(8, 0, 14, 172);

    if (holeMin.y > 0.0f) drawList->AddRectFilled(ImVec2(0.0f, 0.0f), ImVec2(viewportMax.x, holeMin.y), dimColor);
    if (holeMin.x > 0.0f) drawList->AddRectFilled(ImVec2(0.0f, holeMin.y), ImVec2(holeMin.x, holeMax.y), dimColor);
    if (holeMax.x < viewportMax.x) drawList->AddRectFilled(ImVec2(holeMax.x, holeMin.y), ImVec2(viewportMax.x, holeMax.y), dimColor);
    if (holeMax.y < viewportMax.y) drawList->AddRectFilled(ImVec2(0.0f, holeMax.y), viewportMax, dimColor);

    drawList->AddRect(holeMin, holeMax, Theme::GetAccentTintU32(1.0f, 0.18f), 10.0f, 0, 1.0f);
    drawList->PopClipRect();
}

inline void CollapseMenu(StateRefs &state)
{
    state.windowCollapsed = true;
    state.isMenuVisible = false;
    state.collapseBarLastActiveTime = ImGui::GetTime();
    state.collapseBarOpacityAnim = 1.0f;
    state.collapseBarPressAnim = 0.0f;
}

inline float Smooth01(float value)
{
    value = ImClamp(value, 0.0f, 1.0f);
    return value * value * (3.0f - 2.0f * value);
}

struct RevealAnim {
    float time = 0.0f;
    float scale = 1.0f;
    float speed = 3.2f;
    float distance = 42.0f;

    float Value(float delay = 0.0f) const
    {
        return Smooth01((time - delay) * speed);
    }

    ImVec2 Left(const ImVec2 &pos, float delay = 0.0f) const
    {
        const float slide = distance * scale * (1.0f - Value(delay));
        return ImVec2(pos.x - slide, pos.y);
    }

    ImVec2 Right(const ImVec2 &pos, float delay = 0.0f) const
    {
        const float slide = distance * scale * (1.0f - Value(delay));
        return ImVec2(pos.x + slide, pos.y);
    }

    ImVec2 Bottom(const ImVec2 &pos, float delay = 0.0f) const
    {
        const float slide = distance * scale * (1.0f - Value(delay));
        return ImVec2(pos.x, pos.y + slide);
    }
};

inline void DrawHomeTitle(
    ImDrawList *draw,
    ImFont *iconFont,
    ImFont *headerFont,
    ImFont *textFont,
    const ImVec2 &pos,
    float scale,
    ImU32 accent,
    ImU32 white,
    ImU32 muted,
    const char *title,
    const char *sub,
    const char *icon)
{
    if (!draw)
        return;
    ImFont *titleFont = font::auto_techno ? font::auto_techno : (headerFont ? headerFont : ImGui::GetFont());
    ImFont *bodyFont = textFont ? textFont : ImGui::GetFont();
    ImFont *icoFont = iconFont ? iconFont : bodyFont;
    draw->AddText(icoFont, icoFont->FontSize * 0.72f * scale, pos, accent, icon);
    draw->AddText(titleFont, titleFont->FontSize * 0.98f * scale, pos + ImVec2(28.0f, -2.0f) * scale, white, title);
    if (sub && sub[0])
        draw->AddText(bodyFont, bodyFont->FontSize * 0.78f * scale, pos + ImVec2(0.0f, 25.0f) * scale, muted, sub);
}

inline bool HomeCardButton(
    ImDrawList *draw,
    ImFont *iconFont,
    ImFont *textFont,
    const char *id,
    const ImVec2 &pos,
    const ImVec2 &size,
    const char *icon,
    const char *title,
    const char *sub,
    float scale,
    ImU32 accent,
    ImU32 white,
    ImU32 muted,
    ImU32 bg,
    ImU32 hoverBg,
    ImU32 stroke)
{
    ImGui::SetCursorScreenPos(pos);
    ImGui::InvisibleButton(id, size);
    const bool hovered = ImGui::IsItemHovered();
    const bool clicked = ImGui::IsItemClicked();
    ImFont *bodyFont = textFont ? textFont : ImGui::GetFont();
    ImFont *icoFont = iconFont ? iconFont : bodyFont;
    if (draw) {
        draw->AddRectFilled(pos, pos + size, hovered ? hoverBg : bg, 9.0f * scale);
        draw->AddRect(pos, pos + size, hovered ? IM_COL32(105, 91, 255, 120) : stroke, 9.0f * scale, 0, 1.0f * scale);
        const float iconSize = icoFont->FontSize * 0.96f * scale;
        const ImVec2 iconText = icoFont->CalcTextSizeA(iconSize, FLT_MAX, 0.0f, icon);
        draw->AddText(icoFont, iconSize, ImVec2(pos.x + 32.0f * scale, pos.y + (size.y - iconText.y) * 0.5f), accent, icon);
        draw->AddText(bodyFont, bodyFont->FontSize * 0.98f * scale, pos + ImVec2(78.0f, 25.0f) * scale, white, title);
        if (sub && sub[0])
            draw->AddText(bodyFont, bodyFont->FontSize * 0.76f * scale, pos + ImVec2(78.0f, 49.0f) * scale, muted, sub);
    }
    return clicked;
}

inline void BeginHomePanel(
    const char *id,
    ImDrawList *draw,
    ImFont *headerFont,
    const ImVec2 &pos,
    const ImVec2 &size,
    const char *title,
    float scale,
    ImU32 stroke)
{
    if (draw) {
        draw->AddRectFilled(pos, pos + size, IM_COL32(19, 19, 25, 235), 10.0f * scale);
        draw->AddRect(pos, pos + size, stroke, 10.0f * scale, 0, 1.0f * scale);
        ImFont *font = headerFont ? headerFont : ImGui::GetFont();
        draw->AddText(font, font->FontSize * 0.86f * scale, pos + ImVec2(17.0f, 17.0f) * scale, IM_COL32(196, 199, 213, 245), title);
    }
    ImGui::SetCursorScreenPos(pos + ImVec2(17.0f, 48.0f) * scale);
    ImGui::BeginChild(id, ImVec2(size.x - 34.0f * scale, size.y - 62.0f * scale), false, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
}

inline void HomeInfoRow(
    ImDrawList *draw,
    ImFont *iconFont,
    ImFont *textFont,
    const char *icon,
    const char *label,
    const char *value,
    float scale,
    ImU32 accent,
    ImU32 muted,
    ImU32 valueColor)
{
    ImFont *bodyFont = textFont ? textFont : ImGui::GetFont();
    ImFont *icoFont = iconFont ? iconFont : bodyFont;
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float rowW = ImGui::GetContentRegionAvail().x;
    const float rowH = 32.0f * scale;
    if (draw) {
        draw->AddText(icoFont, icoFont->FontSize * 0.48f * scale, p + ImVec2(0.0f, 9.0f) * scale, accent, icon);
        draw->AddText(bodyFont, bodyFont->FontSize * 0.78f * scale, p + ImVec2(26.0f, 7.0f) * scale, muted, label);
        const float valueSize = bodyFont->FontSize * 0.78f * scale;
        const ImVec2 vs = bodyFont->CalcTextSizeA(valueSize, FLT_MAX, 0.0f, value);
        draw->AddText(bodyFont, valueSize, ImVec2(p.x + rowW - vs.x, p.y + 6.0f * scale), valueColor, value);
    }
    ImGui::Dummy(ImVec2(rowW, rowH));
}

inline bool LoginActionButton(
    ImDrawList *draw,
    ImFont *iconFont,
    ImFont *textFont,
    const char *id,
    const char *label,
    const ImVec2 &pos,
    const ImVec2 &size,
    bool disabled)
{
    ImGui::SetCursorScreenPos(pos);
    ImGui::InvisibleButton(id, size);
    const bool held = ImGui::IsItemActive() && !disabled;
    const ImU32 top = held ? Theme::GetAccentTintU32(0.70f, 0.92f) : Theme::GetAccentTintU32(0.98f, 0.92f);
    const ImU32 bot = held ? Theme::GetAccentTintU32(0.42f, 0.95f) : Theme::GetAccentTintU32(0.58f, 0.96f);
    ImFont *bodyFont = textFont ? textFont : ImGui::GetFont();
    ImFont *icoFont = iconFont ? iconFont : bodyFont;
    if (draw) {
        draw->AddRectFilledMultiColor(pos, pos + size, top, top, bot, bot);
        draw->AddRect(pos, pos + size, Theme::GetAccentTintU32(1.0f, 0.72f), 8.0f, 0, 1.0f);
        IconCenter(draw, icoFont, icoFont->FontSize * 0.60f, ImVec2(pos.x + 76.0f, pos.y + size.y * 0.5f), IM_COL32(246, 247, 250, disabled ? 150 : 245), ICON_FA_SIGN_IN_ALT);
        const float fs = bodyFont->FontSize * 1.06f;
        const ImVec2 textSize = bodyFont->CalcTextSizeA(fs, FLT_MAX, 0.0f, label);
        draw->AddText(bodyFont, fs, ImVec2(pos.x + (size.x - textSize.x) * 0.5f + 18.0f, pos.y + (size.y - textSize.y) * 0.5f - 1.0f), IM_COL32(246, 247, 250, disabled ? 150 : 245), label);
    }
    return ImGui::IsItemClicked() && !disabled;
}

inline bool LoginPasteButton(
    ImDrawList *draw,
    ImFont *iconFont,
    ImFont *textFont,
    const ImVec2 &pos,
    const ImVec2 &size,
    bool disabled)
{
    ImGui::SetCursorScreenPos(pos);
    ImGui::InvisibleButton("##Paste", size);
    const bool clicked = ImGui::IsItemClicked() && !disabled;
    ImFont *bodyFont = textFont ? textFont : ImGui::GetFont();
    ImFont *icoFont = iconFont ? iconFont : bodyFont;
    if (draw) {
        draw->AddRectFilled(pos, pos + size, IM_COL32(25, 25, 36, 238), 8.0f);
        draw->AddRect(pos, pos + size, Theme::GetAccentTintU32(0.88f, 0.42f), 8.0f, 0, 1.0f);
        IconCenter(draw, icoFont, icoFont->FontSize * 0.60f, pos + ImVec2(76.0f, size.y * 0.5f), Theme::GetAccentU32(), ICON_FA_PASTE);
        draw->AddText(bodyFont, bodyFont->FontSize * 0.94f, pos + ImVec2(104.0f, 18.0f), IM_COL32(238, 242, 248, 245), "PASTE");
    }
    return clicked;
}

inline void DrawStatusStat(
    ImDrawList *draw,
    ImFont *iconFont,
    ImFont *textFont,
    const ImVec2 &origin,
    float cellWidth,
    float rowStep,
    float scale,
    int col,
    int row,
    const char *icon,
    const char *label,
    const char *value)
{
    if (!draw)
        return;
    ImFont *bodyFont = textFont ? textFont : ImGui::GetFont();
    ImFont *icoFont = iconFont ? iconFont : bodyFont;
    const ImVec2 p(origin.x + col * cellWidth, origin.y + row * rowStep);
    const ImVec2 iconCenter = p + ImVec2(15.0f, 15.0f) * scale;
    draw->AddCircleFilled(iconCenter, 14.0f * scale, IM_COL32(244, 194, 84, 42), 24);
    IconCenter(draw, icoFont, icoFont->FontSize * 0.52f * scale, iconCenter, IM_COL32(244, 194, 84, 245), icon);
    draw->AddText(bodyFont, bodyFont->FontSize * 0.90f * scale, p + ImVec2(38.0f, -1.0f) * scale, IM_COL32(205, 211, 222, 245), label);
    draw->AddText(bodyFont, bodyFont->FontSize * 0.98f * scale, p + ImVec2(38.0f, 19.0f) * scale, IM_COL32(244, 194, 84, 255), value);
}

inline bool QuickActionCard(
    ImDrawList *draw,
    ImFont *iconFont,
    ImFont *textFont,
    const char *id,
    const char *icon,
    const char *label,
    const char *hint,
    const ImVec2 &min,
    float width,
    float height,
    float scale)
{
    ImGui::SetCursorScreenPos(min);
    ImGui::InvisibleButton(id, ImVec2(width, height));
    const bool hovered = ImGui::IsItemHovered();
    const bool clicked = ImGui::IsItemClicked();
    ImFont *bodyFont = textFont ? textFont : ImGui::GetFont();
    ImFont *icoFont = iconFont ? iconFont : bodyFont;
    if (draw) {
        draw->AddRectFilled(min, min + ImVec2(width, height), ImGui::GetColorU32(hovered ? c::field_hover : c::panel_bg), 9.0f * scale);
        draw->AddRect(min, min + ImVec2(width, height), Theme::GetAccentTintU32(1.0f, hovered ? 0.78f : 0.58f), 9.0f * scale, 0, 1.35f * scale);
        const ImVec2 iconBox(min.x + 18.0f * scale, min.y + 14.0f * scale);
        draw->AddRectFilled(iconBox, iconBox + ImVec2(48.0f, 44.0f) * scale, IM_COL32(102, 89, 52, 105), 9.0f * scale);
        IconCenter(draw, icoFont, icoFont->FontSize * 0.88f * scale, iconBox + ImVec2(24.0f, 22.0f) * scale, Theme::GetAccentTintU32(1.0f, 1.0f), icon);
        draw->AddText(bodyFont, bodyFont->FontSize * 0.96f * scale, ImVec2(min.x + 90.0f * scale, min.y + 17.0f * scale), IM_COL32(246, 247, 250, 255), label);
        draw->AddText(bodyFont, bodyFont->FontSize * 0.72f * scale, ImVec2(min.x + 90.0f * scale, min.y + 42.0f * scale), IM_COL32(164, 170, 184, 245), hint);
        const ImVec2 arrow(min.x + width - 34.0f * scale, min.y + height * 0.5f - 7.0f * scale);
        draw->AddText(icoFont, icoFont->FontSize * 0.56f * scale, arrow, Theme::GetAccentTintU32(1.0f, 1.0f), ICON_FA_CHEVRON_RIGHT);
    }
    return clicked;
}

inline bool QuickToggleCard(ImDrawList *draw, const ImVec2 &min, const ImVec2 &size, const char *id, float scale)
{
    ImGui::SetCursorScreenPos(min);
    ImGui::InvisibleButton(id, size);
    const bool hovered = ImGui::IsItemHovered();
    if (draw) {
        draw->AddRectFilled(min, min + size, ImGui::GetColorU32(hovered ? c::field_hover : c::panel_bg), 5.0f * scale);
        draw->AddRect(min, min + size, Theme::GetAccentTintU32(1.0f, 0.56f), 5.0f * scale, 0, 1.4f * scale);
    }
    return ImGui::IsItemClicked();
}

inline void PreviewLimb(ImDrawList *draw, ImVec2 a, ImVec2 b, float thick, ImU32 soft, ImU32 mid, ImU32 bone)
{
    if (!draw)
        return;
    draw->AddLine(a, b, soft, thick + 3.0f);
    draw->AddLine(a, b, mid, thick + 1.4f);
    draw->AddLine(a, b, bone, thick);
}

} // namespace runtime_preview_menu

namespace ImGui {

inline bool AstralInput(const char *label, char *buf, size_t buf_size, const ImVec2 &size = ImVec2(0, 0))
{
    ImGuiWindow *window = GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext &g = *GImGui;
    ImGuiIO &io = g.IO;
    const ImGuiStyle &style = g.Style;
    const ImGuiID id = window->GetID(label);

    static float cursorBlinkTimer = 0.0f;
    static bool cursorVisible = true;

    ImVec2 pos = window->DC.CursorPos;
    ImVec2 inputSize = size;
    if (inputSize.x <= 0.0f)
        inputSize.x = GetContentRegionAvail().x;
    if (inputSize.y <= 0.0f)
        inputSize.y = 50.0f;

    ImRect bb(pos, ImVec2(pos.x + inputSize.x, pos.y + inputSize.y));
    ItemSize(bb, style.FramePadding.y);
    if (!ItemAdd(bb, id))
        return false;

    bool hovered = false;
    bool held = false;
    ButtonBehavior(bb, id, &hovered, &held);
    const bool clicked = hovered && IsMouseClicked(0);
    const bool isActive = g.ActiveId == id;

    if (clicked) {
        SetActiveID(id, window);
        SetFocusID(id, window);
        FocusWindow(window);
    }

    if (isActive) {
        cursorBlinkTimer += io.DeltaTime;
        if (cursorBlinkTimer >= 1.0f) {
            cursorBlinkTimer = 0.0f;
            cursorVisible = !cursorVisible;
        }
    } else {
        cursorBlinkTimer = 0.0f;
        cursorVisible = true;
    }

    ImU32 bgColor = GetColorU32(isActive ? c::elements::background_hovered : hovered ? c::button::background_hovered : c::widget::background);
    ImU32 borderColor = GetColorU32(isActive ? c::accent : c::button::outline);
    ImDrawList *draw_list = window->DrawList;
    draw_list->AddRectFilled(bb.Min, bb.Max, bgColor, 4.0f);
    draw_list->AddRect(bb.Min, bb.Max, borderColor, 4.0f, 0, 1.0f);

    std::string text = buf ? buf : "";
    ImVec2 textPos(bb.Min.x + 64.0f, bb.Min.y + (inputSize.y - GetFontSize()) * 0.5f);
    PushClipRect(ImVec2(bb.Min.x + 58.0f, bb.Min.y), ImVec2(bb.Max.x - 10.0f, bb.Max.y), true);

    if (text.empty() && !isActive) {
        ImVec4 hintColor = c::text::text_hov;
        hintColor.w *= 0.70f;
        draw_list->AddText(textPos, GetColorU32(hintColor), "Enter your key...");
    } else {
        draw_list->AddText(textPos, GetColorU32(c::text::text_active), text.c_str());
        if (isActive && cursorVisible) {
            ImVec2 textSize = CalcTextSize(text.c_str());
            const float cursorX = textPos.x + textSize.x + 2.0f;
            draw_list->AddLine(ImVec2(cursorX, textPos.y), ImVec2(cursorX, textPos.y + GetFontSize()), GetColorU32(c::text::text_active), 2.0f);
        }
    }

    PopClipRect();

    if (isActive) {
        const float animProgress = fmod(cursorBlinkTimer, 1.0f);
        const float lineWidth = bb.GetWidth() * 0.3f;
        const float lineStart = bb.Min.x + (bb.GetWidth() - lineWidth) * 0.5f;
        const float lineEnd = lineStart + lineWidth;
        float alpha = animProgress > 0.5f ? (1.0f - animProgress) * 2.0f : animProgress * 2.0f;
        ImVec4 lineColorF = c::accent;
        lineColorF.w = alpha;
        draw_list->AddLine(ImVec2(lineStart, bb.Max.y - 2.0f), ImVec2(lineEnd, bb.Max.y - 2.0f), GetColorU32(lineColorF), 3.0f);
    }

    return false;
}

} // namespace ImGui

struct SidebarItem {
    const char *icon;
    const char *label;
};

static constexpr SidebarItem kSidebarItems[] = {
    {ICON_FA_HOME, "HOME"},
    {ICON_FA_CROSSHAIRS, "AIMBOT"},
    {ICON_FA_EYE, "VISUALS"},
    {ICON_FA_MICROCHIP, "MEMORY"},
    {ICON_FA_TH_LIST, "WEAPONS"},
    {ICON_FA_USER, "CHARACTER"},
};

inline int SidebarItemCount()
{
    return IM_ARRAYSIZE(kSidebarItems);
}

inline const char *SidebarLabelForPage(int page)
{
    const int index = ImClamp(page - 1, 0, SidebarItemCount() - 1);
    return kSidebarItems[index].label;
}

inline const char *SidebarIconForPage(int page)
{
    const int index = ImClamp(page - 1, 0, SidebarItemCount() - 1);
    return kSidebarItems[index].icon;
}

inline const char *SidebarHintForPage(int page)
{
    switch (page) {
        case 1: return "System Overview";
        case 2: return "Combat Menu";
        case 3: return "ESP Menu";
        case 4: return "Memory Menu";
        case 5: return "Weapon Loadout";
        case 6: return "Character Loadout";
        default: return "System Overview";
    }
}

inline std::string AndroidStaticString(const char *className, const char *fieldName, const char *fallback)
{
    if (jvm == nullptr || className == nullptr || fieldName == nullptr)
        return fallback ? fallback : "";

    JNIEnv *env = nullptr;
    bool attached = false;
    if (jvm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK || env == nullptr)
            return fallback ? fallback : "";
        attached = true;
    }

    std::string result = fallback ? fallback : "";
    jclass klass = env->FindClass(className);
    if (klass != nullptr) {
        jfieldID field = env->GetStaticFieldID(klass, fieldName, "Ljava/lang/String;");
        if (field != nullptr) {
            jstring value = static_cast<jstring>(env->GetStaticObjectField(klass, field));
            if (value != nullptr) {
                const char *chars = env->GetStringUTFChars(value, nullptr);
                if (chars != nullptr) {
                    result = chars;
                    env->ReleaseStringUTFChars(value, chars);
                }
                env->DeleteLocalRef(value);
            }
        }
        env->DeleteLocalRef(klass);
    }

    if (attached)
        jvm->DetachCurrentThread();
    return result;
}

inline std::string DeviceName()
{
    static std::string cached;
    if (!cached.empty())
        return cached;
    const std::string brand = AndroidStaticString("android/os/Build", "BRAND", "Android");
    const std::string model = AndroidStaticString("android/os/Build", "MODEL", "Device");
    cached = brand.empty() || model.empty() || model.find(brand) != std::string::npos ? model : brand + " " + model;
    return cached;
}

inline std::string OsVersion()
{
    static std::string cached;
    if (cached.empty())
        cached = "Android " + AndroidStaticString("android/os/Build$VERSION", "RELEASE", "");
    return cached;
}

inline std::string PackageName()
{
    if (jvm == nullptr)
        return "CODM";
    JNIEnv *env = nullptr;
    bool attached = false;
    if (jvm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (jvm->AttachCurrentThread(&env, nullptr) != JNI_OK || env == nullptr)
            return "CODM";
        attached = true;
    }

    std::string result = "CODM";
    jclass activityThreadClass = env->FindClass("android/app/ActivityThread");
    if (activityThreadClass != nullptr) {
        jfieldID currentThreadField = env->GetStaticFieldID(activityThreadClass, "sCurrentActivityThread", "Landroid/app/ActivityThread;");
        jobject currentThread = currentThreadField ? env->GetStaticObjectField(activityThreadClass, currentThreadField) : nullptr;
        jfieldID applicationField = env->GetFieldID(activityThreadClass, "mInitialApplication", "Landroid/app/Application;");
        jobject application = currentThread && applicationField ? env->GetObjectField(currentThread, applicationField) : nullptr;
        if (application != nullptr) {
            jclass contextClass = env->FindClass("android/content/Context");
            jmethodID getPackageName = contextClass ? env->GetMethodID(contextClass, "getPackageName", "()Ljava/lang/String;") : nullptr;
            jstring packageName = getPackageName ? static_cast<jstring>(env->CallObjectMethod(application, getPackageName)) : nullptr;
            if (packageName != nullptr) {
                const char *chars = env->GetStringUTFChars(packageName, nullptr);
                if (chars != nullptr) {
                    result = chars;
                    env->ReleaseStringUTFChars(packageName, chars);
                }
                env->DeleteLocalRef(packageName);
            }
            if (contextClass) env->DeleteLocalRef(contextClass);
            env->DeleteLocalRef(application);
        }
        if (currentThread) env->DeleteLocalRef(currentThread);
        env->DeleteLocalRef(activityThreadClass);
    }

    if (attached)
        jvm->DetachCurrentThread();
    return result;
}

inline std::string MemoryUsage()
{
    struct sysinfo info {};
    if (sysinfo(&info) != 0 || info.totalram == 0)
        return "Runtime";
    const unsigned long long total = static_cast<unsigned long long>(info.totalram) * info.mem_unit;
    const unsigned long long freeRam = static_cast<unsigned long long>(info.freeram) * info.mem_unit;
    const double usedGb = static_cast<double>(total - freeRam) / (1024.0 * 1024.0 * 1024.0);
    const double totalGb = static_cast<double>(total) / (1024.0 * 1024.0 * 1024.0);
    char buffer[64] = {};
    std::snprintf(buffer, sizeof(buffer), "%.2f GB / %.2f GB", usedGb, totalGb);
    return buffer;
}

inline float MemoryRatio()
{
    struct sysinfo info {};
    if (sysinfo(&info) != 0 || info.totalram == 0)
        return 0.28f;
    const unsigned long long total = static_cast<unsigned long long>(info.totalram) * info.mem_unit;
    const unsigned long long freeRam = static_cast<unsigned long long>(info.freeram + info.bufferram) * info.mem_unit;
    const float used = total > freeRam ? static_cast<float>(total - freeRam) / static_cast<float>(total) : 0.0f;
    return ImClamp(used, 0.01f, 0.98f);
}

inline bool ReadCpu(unsigned long long &idle, unsigned long long &total)
{
    std::ifstream stat("/proc/stat");
    std::string cpu;
    unsigned long long user = 0, nice = 0, system = 0, idleTime = 0, iowait = 0;
    unsigned long long irq = 0, softirq = 0, steal = 0, guest = 0, guestNice = 0;
    if (!(stat >> cpu >> user >> nice >> system >> idleTime >> iowait >> irq >> softirq >> steal >> guest >> guestNice))
        return false;
    idle = idleTime + iowait;
    total = user + nice + system + idleTime + iowait + irq + softirq + steal + guest + guestNice;
    return total > 0;
}

inline float CpuRatio()
{
    static bool ready = false;
    static unsigned long long lastIdle = 0;
    static unsigned long long lastTotal = 0;
    static float smooth = 0.12f;

    unsigned long long idle = 0;
    unsigned long long total = 0;
    if (!ReadCpu(idle, total))
        return smooth;

    if (ready && total > lastTotal) {
        const unsigned long long totalDelta = total - lastTotal;
        const unsigned long long idleDelta = idle > lastIdle ? idle - lastIdle : 0;
        const float used = totalDelta > 0 ? 1.0f - (static_cast<float>(idleDelta) / static_cast<float>(totalDelta)) : smooth;
        smooth += (ImClamp(used, 0.01f, 0.95f) - smooth) * 0.18f;
    }

    lastIdle = idle;
    lastTotal = total;
    ready = true;
    return ImClamp(smooth, 0.01f, 0.95f);
}

inline float ResponseMs()
{
    const float fps = ImGui::GetIO().Framerate;
    const float frameMs = fps > 1.0f ? 1000.0f / fps : 16.0f;
    const float target = ImClamp(frameMs * 0.38f, 1.0f, 60.0f);
    static float smooth = 3.0f;
    smooth += (target - smooth) * 0.08f;
    return ImClamp(smooth, 1.0f, 99.0f);
}

inline size_t DropCurlBody(void *contents, size_t size, size_t nmemb, void *userp)
{
    (void)contents;
    (void)userp;
    return size * nmemb;
}

inline float MeasureNetworkScoreMs()
{
    static std::atomic<bool> curlReady{false};
    if (!curlReady.exchange(true))
        curl_global_init(CURL_GLOBAL_DEFAULT);

    CURL *curl = curl_easy_init();
    if (!curl)
        return -1.0f;

    curl_easy_setopt(curl, CURLOPT_URL, "https://www.cloudflare.com/cdn-cgi/trace");
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT_MS, 1500L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, 2500L);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, DropCurlBody);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

    const CURLcode res = curl_easy_perform(curl);
    double totalSeconds = 0.0;
    double bytesPerSecond = 0.0;
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_TOTAL_TIME, &totalSeconds);
        curl_easy_getinfo(curl, CURLINFO_SPEED_DOWNLOAD, &bytesPerSecond);
    }
    curl_easy_cleanup(curl);

    if (res != CURLE_OK || totalSeconds <= 0.0)
        return -1.0f;

    const float latencyScore = ImClamp(static_cast<float>(totalSeconds * 0.42 * 1000.0), 1.0f, 120.0f);
    const float mbps = static_cast<float>((bytesPerSecond * 8.0) / 1000000.0);
    if (mbps > 0.0f) {
        const float speedT = ImClamp((mbps - 1.0f) / 24.0f, 0.0f, 1.0f);
        return ImMin(latencyScore, ImLerp(120.0f, 1.0f, speedT));
    }

    return latencyScore;
}

inline float PingMs()
{
    static std::atomic<float> cachedMs{0.0f};
    static std::atomic<long long> lastRunMs{0};
    static std::atomic<bool> running{false};

    const long long nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
    const float current = cachedMs.load();
    if (!running.load() && (current <= 0.0f || nowMs - lastRunMs.load() > 5000)) {
        running.store(true);
        lastRunMs.store(nowMs);
        std::thread([]() {
            const float measured = MeasureNetworkScoreMs();
            if (measured > 0.0f)
                cachedMs.store(measured);
            running.store(false);
        }).detach();
    }

    return current > 0.0f ? ImClamp(current, 1.0f, 120.0f) : ImClamp(ResponseMs(), 1.0f, 120.0f);
}

inline std::string ExpiryLabel()
{
    const std::string countdown = getExpiryCountdown();
    if (!EXP.empty() && EXP != " ")
        return EXP + " (" + countdown + ")";
    return countdown.empty() ? "Unknown" : countdown;
}

struct LoginLayout {
    ImVec2 size;
    ImVec2 leftMin;
    ImVec2 leftMax;
    ImVec2 rightMin;
    ImVec2 rightMax;
    ImVec2 authMin;
    float authW;
};

inline LoginLayout LoginShell(ImDrawList *draw, const ImVec2 &pos, const ImVec2 &size)
{
    const float outerRounding = 10.0f;
    const float innerInset = 10.0f;
    const float innerRounding = 12.0f;
    const float outerGlowHeight = size.y * 0.42f;
    const ImVec2 innerMin = pos + ImVec2(innerInset, innerInset);
    const ImVec2 innerMax = pos + size - ImVec2(innerInset, innerInset);
    const float splitX = innerMin.x + ImMin(300.0f, (innerMax.x - innerMin.x) * 0.46f);
    LoginLayout layout{};
    layout.size = size;
    layout.leftMin = innerMin;
    layout.leftMax = ImVec2(splitX, innerMax.y);
    layout.rightMin = ImVec2(splitX, innerMin.y);
    layout.rightMax = innerMax;
    const float rightPad = 76.0f;
    layout.authMin = ImVec2(layout.rightMin.x + rightPad, layout.rightMin.y + 42.0f);
    layout.authW = (layout.rightMax.x - layout.rightMin.x) - rightPad * 2.0f;
    draw->AddRectFilled(pos, pos + size, IM_COL32(18, 18, 22, 126), outerRounding);
    draw->AddRectFilledMultiColor(pos, ImVec2(pos.x + size.x, pos.y + outerGlowHeight), Theme::GetAccentTintU32(0.30f, 0.12f), Theme::GetAccentTintU32(0.16f, 0.05f), IM_COL32(20, 20, 23, 0), IM_COL32(20, 20, 23, 0));
    draw->AddRectFilled(layout.leftMin, layout.leftMax, IM_COL32(27, 27, 33, 150), innerRounding, ImDrawFlags_RoundCornersLeft);
    draw->AddRectFilled(layout.rightMin, layout.rightMax, IM_COL32(20, 20, 24, 218), innerRounding, ImDrawFlags_RoundCornersRight);
    draw->AddRect(innerMin, innerMax, IM_COL32(47, 47, 58, 190), innerRounding, 0, 1.25f);
    return layout;
}

inline void LoginFeatureIcon(ImDrawList *draw, const ImVec2 &center, int iconType, ImU32 accent)
{
    if (iconType == 0) {
        draw->AddRect(ImVec2(center.x - 10.0f, center.y - 10.0f), ImVec2(center.x + 10.0f, center.y + 10.0f), accent, 2.0f, 0, 3.0f);
        draw->AddLine(ImVec2(center.x - 10.0f, center.y - 10.0f), ImVec2(center.x, center.y - 18.0f), accent, 2.0f);
        draw->AddLine(ImVec2(center.x + 10.0f, center.y - 10.0f), ImVec2(center.x, center.y - 18.0f), accent, 2.0f);
    } else if (iconType == 1) {
        draw->AddRect(ImVec2(center.x - 9.0f, center.y - 1.0f), ImVec2(center.x + 9.0f, center.y + 12.0f), accent, 2.0f, 0, 2.0f);
        draw->AddBezierCubic(ImVec2(center.x - 7.0f, center.y - 1.0f), ImVec2(center.x - 7.0f, center.y - 15.0f), ImVec2(center.x + 7.0f, center.y - 15.0f), ImVec2(center.x + 7.0f, center.y - 1.0f), accent, 2.0f, 18);
    } else {
        draw->AddLine(ImVec2(center.x, center.y - 12.0f), ImVec2(center.x - 7.0f, center.y + 1.0f), accent, 4.0f);
        draw->AddLine(ImVec2(center.x, center.y - 12.0f), ImVec2(center.x + 5.0f, center.y - 2.0f), accent, 4.0f);
        draw->AddLine(ImVec2(center.x - 3.0f, center.y), ImVec2(center.x - 8.0f, center.y + 13.0f), accent, 4.0f);
    }
}

inline void LoginFeatureRow(ImDrawList *draw, const ImVec2 &leftMin, float y, int iconType, const char *label, const char *value)
{
    ImFont *labelFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    const ImVec2 iconMin(leftMin.x + 30.0f, y);
    draw->AddRectFilled(iconMin, ImVec2(iconMin.x + 58.0f, iconMin.y + 58.0f), Theme::GetAccentTintU32(0.26f, 0.40f), 10.0f);
    draw->AddRect(iconMin, ImVec2(iconMin.x + 58.0f, iconMin.y + 58.0f), Theme::GetAccentTintU32(0.88f, 0.30f), 10.0f, 0, 1.0f);
    LoginFeatureIcon(draw, ImVec2(iconMin.x + 29.0f, iconMin.y + 29.0f), iconType, Theme::GetAccentU32());
    draw->AddText(labelFont, 13.0f, ImVec2(iconMin.x + 78.0f, iconMin.y + 8.0f), IM_COL32(242, 242, 250, 255), label);
    draw->AddText(labelFont, 12.0f, ImVec2(iconMin.x + 78.0f, iconMin.y + 28.0f), IM_COL32(180, 184, 202, 245), value);
}

inline void LoginBrand(
    ImDrawList *draw,
    const ImVec2 &leftMin,
    const ImVec2 &leftMax,
    const char *brand,
    const char *version,
    const char *edition,
    const char *feature1Title,
    const char *feature1Text,
    const char *feature2Title,
    const char *feature2Text,
    const char *feature3Title,
    const char *feature3Text)
{
    ImFont *brandFont = F50 ? F50 : ImGui::GetFont();
    ImFont *labelFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    const float brandSize = F50 ? 34.0f : brandFont->FontSize * 1.45f;
    const float versionSize = F50 ? 30.0f : brandFont->FontSize * 1.25f;
    const float centerX = (leftMin.x + leftMax.x) * 0.5f;
    const ImVec2 brandSizePx = brandFont->CalcTextSizeA(brandSize, FLT_MAX, 0.0f, brand);
    const ImVec2 versionSizePx = brandFont->CalcTextSizeA(versionSize, FLT_MAX, 0.0f, version);
    draw->AddText(brandFont, brandSize, ImVec2(centerX - brandSizePx.x * 0.5f, leftMin.y + 46.0f), Theme::GetAccentU32(), brand);
    draw->AddText(brandFont, versionSize, ImVec2(centerX - versionSizePx.x * 0.5f, leftMin.y + 90.0f), IM_COL32(255, 255, 255, 255), version);
    const ImVec2 editionSize = labelFont->CalcTextSizeA(13.0f, FLT_MAX, 0.0f, edition);
    draw->AddText(labelFont, 13.0f, ImVec2(centerX - editionSize.x * 0.5f, leftMin.y + 132.0f), IM_COL32(190, 190, 205, 245), edition);
    LoginFeatureRow(draw, leftMin, leftMin.y + 190.0f, 0, feature1Title, feature1Text);
    LoginFeatureRow(draw, leftMin, leftMin.y + 270.0f, 1, feature2Title, feature2Text);
    LoginFeatureRow(draw, leftMin, leftMin.y + 350.0f, 2, feature3Title, feature3Text);
}

inline void LoginWelcome(ImDrawList *draw, const ImVec2 &authMin, float authW, const char *welcomeA, const char *welcomeB, const char *subtitle)
{
    ImFont *titleFont = F50 ? F50 : ImGui::GetFont();
    ImFont *labelFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    const ImVec2 welcomeASize = titleFont->CalcTextSizeA(24.0f, FLT_MAX, 0.0f, welcomeA);
    const ImVec2 welcomeBSize = titleFont->CalcTextSizeA(24.0f, FLT_MAX, 0.0f, welcomeB);
    const float x = authMin.x + (authW - welcomeASize.x - welcomeBSize.x) * 0.5f;
    draw->AddText(titleFont, 24.0f, ImVec2(x, authMin.y + 46.0f), IM_COL32(250, 242, 255, 255), welcomeA);
    draw->AddText(titleFont, 24.0f, ImVec2(x + welcomeASize.x, authMin.y + 46.0f), Theme::GetAccentU32(), welcomeB);
    const ImVec2 subSize = labelFont->CalcTextSizeA(13.0f, FLT_MAX, 0.0f, subtitle);
    draw->AddText(labelFont, 13.0f, ImVec2(authMin.x + (authW - subSize.x) * 0.5f, authMin.y + 80.0f), IM_COL32(150, 154, 172, 245), subtitle);
}

struct Geometry {
    ImVec2 bodyMin;
    ImVec2 bodyMax;
    ImVec2 sidebarMin;
    ImVec2 sidebarMax;
    ImVec2 contentMin;
    ImVec2 contentMax;
    ImVec2 titleCardMin;
    ImVec2 titleCardSize;
    ImVec2 saveButtonMin;
    ImVec2 loadButtonMin;
    ImVec2 closeButtonMin;
    ImVec2 actionButtonSize;
    ImVec2 hostMin;
    ImVec2 hostMax;
    ImVec2 contentInnerMin;
    ImVec2 contentInnerSize;
};

inline Geometry BuildGeometry(
    const ImVec2 &windowPos,
    const ImVec2 &windowSize,
    float uiScale,
    float outerPad,
    float sidebarWidth,
    float contentPad,
    float headerHeight,
    const ImVec2 &headerActionSize,
    float headerActionGap)
{
    Geometry g{};
    g.bodyMin = ImVec2(windowPos.x + outerPad, windowPos.y + outerPad);
    g.bodyMax = ImVec2(windowPos.x + windowSize.x - outerPad, windowPos.y + windowSize.y - outerPad);
    const float gap = 0.0f * uiScale;
    g.titleCardMin = ImVec2(g.bodyMin.x + sidebarWidth, g.bodyMin.y);
    g.titleCardSize = ImVec2(g.bodyMax.x - g.titleCardMin.x, headerHeight);
    g.sidebarMin = ImVec2(g.bodyMin.x, g.bodyMin.y);
    g.sidebarMax = ImVec2(g.sidebarMin.x + sidebarWidth, g.bodyMax.y);
    g.contentMin = ImVec2(g.bodyMin.x + sidebarWidth + contentPad, g.bodyMin.y + headerHeight);
    g.contentMax = ImVec2(g.bodyMax.x, g.bodyMax.y);
    const float headerActionY = g.titleCardMin.y + 20.0f * uiScale;
    const float headerActionX = g.contentMax.x - headerActionSize.x - 20.0f * uiScale;
    g.saveButtonMin = ImVec2(headerActionX - (headerActionSize.x + headerActionGap) * 2.0f, headerActionY);
    g.loadButtonMin = ImVec2(headerActionX - (headerActionSize.x + headerActionGap), headerActionY);
    g.closeButtonMin = ImVec2(headerActionX, headerActionY);
    g.actionButtonSize = headerActionSize;

    g.hostMin = g.contentMin;
    g.hostMax = g.contentMax;
    g.contentInnerMin = g.hostMin;
    g.contentInnerSize = ImVec2(ImMax(0.0f, g.hostMax.x - g.hostMin.x), ImMax(0.0f, g.hostMax.y - g.hostMin.y));
    return g;
}

inline void WindowShell(ImDrawList *draw, const ImVec2 &windowPos, const ImVec2 &windowSize, float uiScale)
{
    const float rounding = 16.0f * uiScale;
    const ImVec2 shellMin = windowPos;
    const ImVec2 shellMax(windowPos.x + windowSize.x, windowPos.y + windowSize.y);
    for (int i = 7; i >= 1; --i) {
        const float spread = (float)i * 1.45f * uiScale;
        const int alpha = 7 + i * 3;
        draw->AddRect(shellMin - ImVec2(spread, spread), shellMax + ImVec2(spread, spread), IM_COL32(0, 0, 0, alpha), rounding + spread, 0, 1.0f * uiScale);
    }
    draw->AddRectFilled(shellMin, shellMax, IM_COL32(25, 25, 32, 96), rounding);
    draw->AddRect(shellMin, shellMax, IM_COL32(54, 55, 66, 185), rounding, 0, 1.0f * uiScale);
}

inline bool HeaderTitle(ImDrawList *draw, const char *title, const char *pageIcon, const char *subtitle, const ImVec2 &titleCardMin, const ImVec2 &titleCardSize, float uiScale)
{
    (void)title;
    (void)pageIcon;
    (void)subtitle;
    ImFont *headerFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    const ImVec2 headerMax = titleCardMin + titleCardSize;
    draw->AddRectFilled(titleCardMin, headerMax, IM_COL32(17, 17, 22, 235), 0.0f);

    ImFont *brandFont = font::inter_semibold ? font::inter_semibold : headerFont;
    const char *brand = "ASTRAL V47";
    const float nameSize = brandFont->FontSize * 1.05f * uiScale;
    const ImVec2 brandSize = brandFont->CalcTextSizeA(nameSize, FLT_MAX, 0.0f, brand);
    draw->PushClipRect(titleCardMin + ImVec2(8.0f, 0.0f) * uiScale, headerMax - ImVec2(56.0f, 0.0f) * uiScale, true);
    draw->AddText(brandFont, nameSize, titleCardMin + ImVec2(18.0f, (titleCardSize.y / uiScale - brandSize.y / uiScale) * 0.5f) * uiScale, IM_COL32(255, 255, 255, 255), brand);
    draw->PopClipRect();

    const ImVec2 closeSize(42.0f * uiScale, 42.0f * uiScale);
    const ImVec2 closeMin(headerMax - ImVec2(closeSize.x + 10.0f * uiScale, titleCardSize.y - (titleCardSize.y - closeSize.y) * 0.5f));
    ImGui::SetCursorScreenPos(closeMin);
    ImGui::InvisibleButton("raspody_header_collapse", closeSize);
    const bool hovered = ImGui::IsItemHovered();
    const bool held = ImGui::IsItemActive();
    const bool clicked = ImGui::IsItemClicked();
    draw->AddRectFilled(closeMin, closeMin + closeSize, ImGui::GetColorU32(held ? c::raspody::widget_active : hovered ? c::raspody::widget_hover : c::raspody::widget), 15.0f * uiScale);
    draw->AddRect(closeMin, closeMin + closeSize, ImGui::GetColorU32(c::raspody::separator), 15.0f * uiScale, 0, 1.0f * uiScale);
    ImFont *iconFont = F107 ? F107 : headerFont;
    const char *chev = ICON_FA_CHEVRON_LEFT;
    const float iconSize = (F107 ? 22.0f : 18.0f) * uiScale;
    const ImVec2 iconText = iconFont->CalcTextSizeA(iconSize, FLT_MAX, 0.0f, chev);
    draw->AddText(iconFont, iconSize, closeMin + ImVec2((closeSize.x - iconText.x) * 0.5f, (closeSize.y - iconText.y) * 0.5f), IM_COL32(151, 151, 179, 255), chev);
    return clicked;
}

inline void ContentHeader(ImDrawList *draw, const ImVec2 &min, const ImVec2 &size, int page, float uiScale)
{
    (void)draw;
    (void)min;
    (void)size;
    (void)page;
    (void)uiScale;
}

inline bool CloseButton(ImDrawList *draw, const ImVec2 &p, const ImVec2 &size, float uiScale)
{
    ImGui::SetCursorScreenPos(p);
    ImGui::InvisibleButton("header_close_compact", size);
    const bool hovered = ImGui::IsItemHovered();
    const bool held = ImGui::IsItemActive();
    const bool clicked = ImGui::IsItemClicked();
    const ImU32 fill = held ? IM_COL32(35, 35, 46, 255) : hovered ? IM_COL32(28, 28, 39, 255) : IM_COL32(20, 20, 27, 255);
    draw->AddRectFilled(p, p + size, fill, 8.0f * uiScale);
    draw->AddRect(p, p + size, IM_COL32(25, 25, 33, 255), 8.0f * uiScale, 0, 1.0f * uiScale);

    const ImU32 mark = IM_COL32(151, 151, 179, 255);
    const float lineW = 15.0f * uiScale;
    const float lineX = p.x + (size.x - lineW) * 0.5f;
    const float lineY = p.y + size.y * 0.5f - 5.0f * uiScale;
    for (int i = 0; i < 3; ++i) {
        const float y = lineY + i * 5.0f * uiScale;
        draw->AddLine(ImVec2(lineX, y), ImVec2(lineX + lineW, y), mark, 2.0f * uiScale);
    }
    return clicked;
}

inline void SidebarBrand(ImDrawList *draw, const ImVec2 &sidebarMin, float sidebarWidth, float uiScale)
{
    (void)draw;
    (void)sidebarMin;
    (void)sidebarWidth;
    (void)uiScale;
}

inline void SidebarUserCard(ImDrawList *draw, const ImVec2 &sidebarMin, const ImVec2 &sidebarMax, float sidebarWidth, float uiScale)
{
    (void)draw;
    (void)sidebarMin;
    (void)sidebarMax;
    (void)sidebarWidth;
    (void)uiScale;
}

inline bool HeaderAction(
    ImDrawList *draw,
    const char *id,
    const char *icon,
    const char *label,
    const ImVec2 &p,
    const ImVec2 &size,
    ImU32 fill,
    ImU32 border,
    ImU32 textColor,
    float uiScale,
    ImFont *headerFont)
{
    ImGui::SetCursorScreenPos(p);
    ImGui::InvisibleButton(id, size);
    const bool hovered = ImGui::IsItemHovered();
    const bool held = ImGui::IsItemActive();
    const bool clicked = ImGui::IsItemClicked();
    ImU32 actualFill = fill;
    if (hovered) actualFill = ImGui::GetColorU32(c::raspody::widget_hover);
    if (held) actualFill = ImGui::GetColorU32(c::raspody::widget_active);
    draw->AddRectFilled(p, p + size, actualFill, 15.0f * uiScale);
    draw->AddRect(p, p + size, border, 15.0f * uiScale, 0, 1.0f);
    ImFont *iconFont = F107 ? F107 : headerFont;
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    const float iconSize = (F107 ? 14.0f : 12.0f) * uiScale;
    const float labelSize = textFont->FontSize * 0.72f * uiScale;
    const ImVec2 iconText = iconFont->CalcTextSizeA(iconSize, FLT_MAX, 0.0f, icon);
    const ImVec2 labelText = textFont->CalcTextSizeA(labelSize, FLT_MAX, 0.0f, label);
    const float groupW = iconText.x + 9.0f * uiScale + labelText.x;
    const float x = p.x + (size.x - groupW) * 0.5f;
    draw->AddText(iconFont, iconSize, ImVec2(x, p.y + (size.y - iconText.y) * 0.5f), textColor, icon);
    draw->AddText(textFont, labelSize, ImVec2(x + iconText.x + 9.0f * uiScale, p.y + (size.y - labelText.y) * 0.5f), textColor, label);
    return clicked;
}

inline bool HeaderAction(
    ImDrawList *draw,
    const char *icon,
    const char *label,
    const ImVec2 &buttonMin,
    const ImVec2 &buttonSize,
    ImU32 fill,
    ImU32 border,
    ImU32 text,
    float uiScale,
    ImFont *fontFace)
{
    char id[64] = {};
    std::snprintf(id, sizeof(id), "header_%s", label ? label : "action");
    return HeaderAction(draw, id, icon, label, buttonMin, buttonSize, fill, border, text, uiScale, fontFace);
}

inline bool SidebarButton(
    ImDrawList *draw,
    const char *id,
    const char *icon,
    const char *label,
    const ImVec2 &buttonMin,
    const ImVec2 &buttonSize,
    bool active,
    float uiScale)
{
    (void)label;
    ImGui::SetCursorScreenPos(buttonMin);
    ImGui::InvisibleButton(id, buttonSize);
    const bool hovered = ImGui::IsItemHovered();
    const bool clicked = ImGui::IsItemClicked();
    const ImVec2 buttonMax(buttonMin.x + buttonSize.x, buttonMin.y + buttonSize.y);
    const float tile = 33.0f * uiScale;
    const ImVec2 tileMin(buttonMin.x + (buttonSize.x - tile) * 0.5f, buttonMin.y + (buttonSize.y - tile) * 0.5f);
    const ImVec2 tileMax(tileMin.x + tile, tileMin.y + tile);
    if (!active && hovered)
        draw->AddRectFilled(tileMin, tileMax, IM_COL32(33, 33, 39, 110), 4.0f * uiScale);
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    const float iconSize = 20.0f * uiScale;
    const ImVec2 iconText = iconFont->CalcTextSizeA(iconSize, FLT_MAX, 0.0f, icon);
    const float midX = buttonMin.x + buttonSize.x * 0.5f;
    const float midY = buttonMin.y + buttonSize.y * 0.5f;
    draw->AddText(iconFont, iconSize, ImVec2(midX - iconText.x * 0.5f, midY - iconText.y * 0.5f), active ? IM_COL32(255, 255, 255, 255) : IM_COL32(79, 79, 96, 255), icon);
    return clicked;
}

inline void Card(const char *icon, const char *label, const char *value, const char *hint, ImU32 color)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    const ImVec2 circle(p.x + 45.0f, p.y + 42.0f);
    draw->AddCircleFilled(circle, 30.0f, ImAlphaBlendColors(IM_COL32(20, 20, 26, 255), color & IM_COL32(255, 255, 255, 130)), 36);
    const float iconSize = F107 ? 24.0f : 20.0f;
    const ImVec2 iconText = iconFont->CalcTextSizeA(iconSize, FLT_MAX, 0.0f, icon);
    draw->AddText(iconFont, iconSize, circle - iconText * 0.5f, Theme::GetAccentTintU32(1.0f, 1.0f), icon);
    draw->AddText(textFont, textFont->FontSize * 0.92f, ImVec2(p.x + 88.0f, p.y + 20.0f), IM_COL32(235, 235, 242, 255), label);
    draw->AddText(textFont, textFont->FontSize * 0.90f, ImVec2(p.x + 88.0f, p.y + 47.0f), Theme::GetAccentTintU32(1.0f, 0.95f), value);
    draw->AddText(textFont, textFont->FontSize * 0.78f, ImVec2(p.x + 88.0f, p.y + 72.0f), IM_COL32(172, 176, 188, 245), hint);
    ImGui::Dummy(ImVec2(w, 105.0f));
}

inline void Info(const char *label, const char *value, ImU32 valueColor = 0, const char *icon = nullptr)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    const float rowH = 26.0f;
    if (icon && icon[0]) {
    draw->AddText(iconFont, F107 ? 12.0f : 10.0f, ImVec2(p.x + 4.0f, p.y + 5.0f), Theme::GetAccentTintU32(1.0f, 0.88f), icon);
    }
    draw->AddText(textFont, textFont->FontSize * 0.82f, ImVec2(p.x + 24.0f, p.y + 5.0f), IM_COL32(178, 181, 194, 245), label);
    const ImU32 actualValueColor = valueColor ? valueColor : IM_COL32(210, 217, 232, 255);
    const ImVec2 valueSize = textFont->CalcTextSizeA(textFont->FontSize * 0.82f, FLT_MAX, 0.0f, value);
    draw->AddText(textFont, textFont->FontSize * 0.82f, ImVec2(p.x + w - valueSize.x - 8.0f, p.y + 5.0f), actualValueColor, value);
    ImGui::Dummy(ImVec2(w, rowH));
}

inline void OverviewHero(const char *licenseValue, const char *licenseHint, float uiScale)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    const float h = ImGui::GetContentRegionAvail().y;
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    ImFont *titleFont = font::angas_ultra ? font::angas_ultra : textFont;

    draw->AddRectFilled(p, p + ImVec2(w, h), IM_COL32(13, 20, 25, 42), 8.0f * uiScale);
    const float titleSize = titleFont->FontSize * 1.36f * uiScale;
    const ImVec2 titlePos = p + ImVec2(48.0f, 12.0f) * uiScale;
    const ImVec2 titleText = titleFont->CalcTextSizeA(titleSize, FLT_MAX, 0.0f, "SYSTEM STATUS");
    runtime_preview_menu::IconCenter(draw, iconFont, (F107 ? 16.0f : 14.0f) * uiScale, ImVec2(p.x + 27.0f * uiScale, titlePos.y + titleText.y * 0.50f), IM_COL32(244, 194, 84, 245), ICON_FA_HEARTBEAT);
    draw->AddText(titleFont, titleSize, titlePos, IM_COL32(246, 247, 250, 255), "SYSTEM STATUS");

    const float footerH = 45.0f * uiScale;
    const float bodyTop = p.y + 58.0f * uiScale;
    const float bodyBottom = p.y + h - footerH;
    const float dividerX = p.x + w * 0.45f;
    draw->AddLine(ImVec2(dividerX, bodyTop + 4.0f * uiScale), ImVec2(dividerX, bodyBottom - 2.0f * uiScale), IM_COL32(154, 160, 170, 70), 1.7f * uiScale);

    const ImVec2 logoCenter(p.x + w * 0.215f, bodyTop + (bodyBottom - bodyTop) * 0.48f);
    const float logoR = ImMin(w * 0.125f, (bodyBottom - bodyTop) * 0.36f);
    const float time = (float)ImGui::GetTime();
    static float scanStart = 0.0f;
    if (scanStart <= 0.0f)
        scanStart = time;
    const float scanElapsed = time - scanStart;
    const float scanProgress = ImClamp(scanElapsed / 3.0f, 0.0f, 1.0f);
    const bool scanDone = scanElapsed >= 5.0f;
    const float pulse = scanDone ? 1.0f : scanProgress;
    draw->AddCircle(logoCenter, logoR + 22.0f * uiScale, IM_COL32(154, 160, 170, 34), 96, 1.0f * uiScale);
    draw->AddCircle(logoCenter, logoR + 9.0f * uiScale, IM_COL32(244, 194, 84, 42), 96, 1.1f * uiScale);
    const float sweepStart = -IM_PI * 0.72f;
    const float sweep = IM_PI * 1.44f * pulse;
    ImVec2 scanPts[56];
    const int scanCount = ImMax(3, (int)(pulse * 48.0f));
    for (int i = 0; i < scanCount; ++i) {
        const float t = (float)i / (float)(scanCount - 1);
        const float a = sweepStart + sweep * t;
        const float r = logoR + 16.0f * uiScale;
        scanPts[i] = ImVec2(logoCenter.x + cosf(a) * r, logoCenter.y + sinf(a) * r);
    }
    draw->AddPolyline(scanPts, scanCount, IM_COL32(244, 194, 84, 170), false, 2.8f * uiScale);
    draw->AddNgonFilled(logoCenter, logoR * 0.74f, IM_COL32(12, 18, 20, 188), 6);
    draw->AddNgon(logoCenter, logoR * 0.88f, IM_COL32(244, 194, 84, 56), 6, 1.3f * uiScale);
    draw->AddNgon(logoCenter, logoR * 0.70f, IM_COL32(244, 194, 84, 235), 6, 2.8f * uiScale);
    draw->AddNgon(logoCenter, logoR * 0.49f, IM_COL32(154, 160, 170, 70), 6, 1.1f * uiScale);
    ImFont *brandFont = font::angas_ultra ? font::angas_ultra : (F50 ? F50 : textFont);
    const float aSize = ImMax(36.0f * uiScale, logoR * 0.70f);
    const ImVec2 aText = brandFont->CalcTextSizeA(aSize, FLT_MAX, 0.0f, "A");
    draw->AddText(brandFont, aSize, logoCenter - aText * 0.5f, IM_COL32(238, 197, 94, 255), "A");

    const float textX = dividerX + 28.0f * uiScale;
    const float textY = bodyTop + 4.0f * uiScale;
    const float heroTitle = titleFont->FontSize * 1.34f * uiScale;
    const ImVec2 sysSize = titleFont->CalcTextSizeA(heroTitle, FLT_MAX, 0.0f, "SYSTEM");
    const ImVec2 readySize = titleFont->CalcTextSizeA(heroTitle, FLT_MAX, 0.0f, "READY");
    draw->AddText(titleFont, heroTitle, ImVec2(textX, textY), IM_COL32(246, 247, 250, 255), "SYSTEM");
    const float readyX = textX + sysSize.x + 20.0f * uiScale;
    draw->AddText(titleFont, heroTitle, ImVec2(readyX, textY), IM_COL32(244, 194, 84, 255), "READY");
    const ImVec2 readyCenter(readyX + readySize.x + 8.0f * uiScale, textY + heroTitle * 0.48f);
    draw->AddCircleFilled(readyCenter, 4.4f * uiScale, IM_COL32(244, 194, 84, 230), 16);
    runtime_preview_menu::IconCenter(draw, iconFont, 4.0f * uiScale, readyCenter, IM_COL32(12, 15, 19, 255), ICON_FA_CHECK);
    const float readyBottom = textY + 36.0f * uiScale;

    const float gridTop = readyBottom + 20.0f * uiScale;
    const float gridLeft = textX;
    const float gridRight = p.x + w - 28.0f * uiScale;
    const float rowStep = ImMax(38.0f * uiScale, (bodyBottom - gridTop - 10.0f * uiScale) / 3.0f);
    draw->AddLine(ImVec2(gridLeft, gridTop - 9.0f * uiScale), ImVec2(gridRight, gridTop - 9.0f * uiScale), IM_COL32(154, 160, 170, 58), 1.0f * uiScale);
    draw->AddLine(ImVec2(gridLeft, gridTop + rowStep - 4.0f * uiScale), ImVec2(gridRight, gridTop + rowStep - 4.0f * uiScale), IM_COL32(154, 160, 170, 38), 1.0f * uiScale);
    draw->AddLine(ImVec2(gridLeft, gridTop + rowStep * 2.0f - 4.0f * uiScale), ImVec2(gridRight, gridTop + rowStep * 2.0f - 4.0f * uiScale), IM_COL32(154, 160, 170, 38), 1.0f * uiScale);
    draw->AddLine(ImVec2(gridLeft + (gridRight - gridLeft) * 0.5f - 10.0f * uiScale, gridTop - 2.0f * uiScale), ImVec2(gridLeft + (gridRight - gridLeft) * 0.5f - 10.0f * uiScale, bodyBottom - 8.0f * uiScale), IM_COL32(154, 160, 170, 30), 1.0f * uiScale);
    const float cellW = (p.x + w - 34.0f * uiScale - textX) * 0.5f;
    const ImVec2 statOrigin(textX, gridTop);
    runtime_preview_menu::DrawStatusStat(draw, iconFont, textFont, statOrigin, cellW, rowStep, uiScale, 0, 0, ICON_FA_COG, "Modules", "12 / 12");
    runtime_preview_menu::DrawStatusStat(draw, iconFont, textFont, statOrigin, cellW, rowStep, uiScale, 1, 0, ICON_FA_TACHOMETER, "Performance", "Optimal");
    runtime_preview_menu::DrawStatusStat(draw, iconFont, textFont, statOrigin, cellW, rowStep, uiScale, 0, 1, ICON_FA_SHIELD, "Security", "Secure");
    runtime_preview_menu::DrawStatusStat(draw, iconFont, textFont, statOrigin, cellW, rowStep, uiScale, 1, 1, ICON_FA_BRIEFCASE, "Driver", "Loaded");
    runtime_preview_menu::DrawStatusStat(draw, iconFont, textFont, statOrigin, cellW, rowStep, uiScale, 0, 2, ICON_FA_DOWNLOAD, "Injection", "Stable");
    runtime_preview_menu::DrawStatusStat(draw, iconFont, textFont, statOrigin, cellW, rowStep, uiScale, 1, 2, ICON_FA_CHECK_SQUARE, "Integrity", "Verified");

    const ImVec2 footMin(p.x, p.y + h - footerH);
    draw->AddLine(footMin, ImVec2(p.x + w, footMin.y), IM_COL32(154, 160, 170, 64), 1.3f * uiScale);
    const ImVec2 checkCenter(p.x + w - 22.0f * uiScale, footMin.y + 21.0f * uiScale);
    const float pctSize = textFont->FontSize * 0.94f * uiScale;
    const ImVec2 pctText = textFont->CalcTextSizeA(pctSize, FLT_MAX, 0.0f, "100%");
    const ImVec2 pctPos(checkCenter.x - 16.0f * uiScale - pctText.x, footMin.y + 10.0f * uiScale);
    const float barW = ImMax(40.0f * uiScale, pctPos.x - (footMin.x + 20.0f * uiScale) - 16.0f * uiScale);
    const ImVec2 barMin(footMin.x + 20.0f * uiScale, footMin.y + 18.0f * uiScale);
    const ImVec2 barMax(barMin.x + barW, barMin.y + 10.0f * uiScale);
    draw->AddRectFilled(barMin, barMax, IM_COL32(29, 31, 36, 230), 6.0f * uiScale);
    draw->AddRectFilled(barMin, ImVec2(barMin.x + barW * scanProgress, barMax.y), IM_COL32(244, 194, 84, 255), 6.0f * uiScale);
    char scanPct[8] = {};
    std::snprintf(scanPct, sizeof(scanPct), "%d%%", (int)(scanProgress * 100.0f + 0.5f));
    draw->AddText(textFont, pctSize, pctPos, IM_COL32(246, 247, 250, 255), scanPct);
    if (scanDone) {
        draw->AddCircle(checkCenter, 8.0f * uiScale, IM_COL32(244, 194, 84, 245), 28, 1.35f * uiScale);
        runtime_preview_menu::IconCenter(draw, iconFont, (F107 ? 7.0f : 6.5f) * uiScale, checkCenter, IM_COL32(244, 194, 84, 255), ICON_FA_CHECK);
    }
    ImGui::Dummy(ImVec2(w, h));
}

inline std::string MaskKey(const char *key)
{
    if (key == nullptr || key[0] == '\0')
        return "Unknown";
    std::string raw(key);
    if (raw.size() <= 4)
        return raw;
    const size_t left = ImMin((size_t)3, raw.size() / 2);
    const size_t right = ImMin((size_t)2, raw.size() - left);
    return raw.substr(0, left) + "******" + raw.substr(raw.size() - right);
}

inline void LicenseCard(const char *licenseValue, const char *licenseHint, const char *licenseKey, float uiScale)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    const float h = ImGui::GetContentRegionAvail().y;
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    ImFont *titleFont = font::angas_ultra ? font::angas_ultra : textFont;

    const ImU32 gold = Theme::GetAccentTintU32(1.0f, 1.0f);
    const ImU32 goldDim = Theme::GetAccentTintU32(1.0f, 0.46f);
    draw->AddRectFilled(p, p + ImVec2(w, h), IM_COL32(8, 14, 20, 68), 8.0f * uiScale);

    for (int i = 0; i < 12; ++i) {
        const float y = p.y + h * 0.56f + i * 5.0f * uiScale;
        draw->AddBezierCubic(
            ImVec2(p.x - 10.0f * uiScale, y + 28.0f * uiScale),
            ImVec2(p.x + w * 0.10f, y - 22.0f * uiScale),
            ImVec2(p.x + w * 0.22f, y + 30.0f * uiScale),
            ImVec2(p.x + w * 0.38f, y - 10.0f * uiScale),
            IM_COL32(238, 197, 94, 12), 1.0f * uiScale);
    }
    for (int i = 0; i < 14; ++i) {
        const float y = p.y + 6.0f * uiScale + i * 6.5f * uiScale;
        draw->AddBezierCubic(
            ImVec2(p.x + w * 0.64f, y),
            ImVec2(p.x + w * 0.80f, y + 52.0f * uiScale),
            ImVec2(p.x + w * 0.90f, y - 30.0f * uiScale),
            ImVec2(p.x + w - 10.0f * uiScale, y + 26.0f * uiScale),
            IM_COL32(238, 197, 94, 14), 1.0f * uiScale);
    }

    const float pad = 24.0f * uiScale;
    const float footH = 34.0f * uiScale;
    const float footGap = 18.0f * uiScale;
    const float topH = h - pad - footGap - footH;
    const float headY = p.y + pad;
    const float headSize = titleFont->FontSize * 1.00f * uiScale;
    const ImVec2 headText = titleFont->CalcTextSizeA(headSize, FLT_MAX, 0.0f, "LICENSE");
    runtime_preview_menu::IconCenter(draw, iconFont, (F107 ? 14.0f : 12.0f) * uiScale, ImVec2(p.x + pad + 10.0f * uiScale, headY + headText.y * 0.50f), gold, ICON_FA_LOCK);
    draw->AddText(titleFont, headSize, ImVec2(p.x + pad + 26.0f * uiScale, headY), IM_COL32(246, 247, 250, 255), "LICENSE");

    const float bodyTop = headY + headText.y + 24.0f * uiScale;
    const float bodyBottom = p.y + topH;
    const ImVec2 center(p.x + pad + (w * 0.43f - pad) * 0.50f, bodyTop + (bodyBottom - bodyTop) * 0.48f);
    const float badgeR = ImMin(66.0f * uiScale, (bodyBottom - bodyTop) * 0.42f);
    draw->AddNgonFilled(center, badgeR * 0.92f, IM_COL32(20, 22, 22, 178), 6);
    draw->AddNgon(center, badgeR, goldDim, 6, 1.9f * uiScale);
    const float lockSize = ImMax(28.0f * uiScale, badgeR * 0.70f);
    const ImVec2 lockText = iconFont->CalcTextSizeA(lockSize, FLT_MAX, 0.0f, ICON_FA_LOCK);
    draw->AddText(iconFont, lockSize, center - lockText * 0.5f, gold, ICON_FA_LOCK);

    const float divX = p.x + w * 0.43f;
    draw->AddLine(ImVec2(divX, bodyTop - 8.0f * uiScale), ImVec2(divX, bodyBottom - 2.0f * uiScale), IM_COL32(154, 160, 170, 48), 1.2f * uiScale);

    const float infoX = divX + pad;
    const char *premium = licenseValue && licenseValue[0] ? licenseValue : "Premium";
    const float premiumSize = titleFont->FontSize * 1.02f * uiScale;
    const float premiumY = bodyTop + 2.0f * uiScale;
    const ImVec2 premiumText = titleFont->CalcTextSizeA(premiumSize, FLT_MAX, 0.0f, premium);
    runtime_preview_menu::IconCenter(draw, iconFont, (F107 ? 16.0f : 14.0f) * uiScale, ImVec2(infoX + 8.0f * uiScale, premiumY + premiumText.y * 0.50f), gold, ICON_FA_CHECK_CIRCLE);
    draw->AddText(titleFont, premiumSize, ImVec2(infoX + 28.0f * uiScale, premiumY), gold, premium);
    const float activeY = premiumY + 30.0f * uiScale;
    const std::string maskedKey = MaskKey(licenseKey);
    draw->AddText(textFont, textFont->FontSize * 0.78f * uiScale, ImVec2(infoX, activeY), IM_COL32(178, 184, 196, 245), maskedKey.c_str());
    const float statusY = activeY + 23.0f * uiScale;
    draw->AddText(textFont, textFont->FontSize * 0.84f * uiScale, ImVec2(infoX, statusY), IM_COL32(206, 211, 222, 245), "Your license is active");
    draw->AddCircleFilled(ImVec2(infoX + 140.0f * uiScale, statusY + 8.0f * uiScale), 5.0f * uiScale, IM_COL32(70, 220, 80, 245), 12);
    const ImVec2 activeCheck = iconFont->CalcTextSizeA(5.0f * uiScale, FLT_MAX, 0.0f, ICON_FA_CHECK);
    draw->AddText(iconFont, 5.0f * uiScale, ImVec2(infoX + 140.0f * uiScale, statusY + 8.0f * uiScale) - activeCheck * 0.5f, IM_COL32(8, 14, 20, 255), ICON_FA_CHECK);

    const char *hint = licenseHint && licenseHint[0] ? licenseHint : "Lifetime";
    const ImVec2 footMin(p.x + pad, p.y + h - pad - footH);
    const ImVec2 footMax(p.x + w - pad, p.y + h - pad);
    draw->AddRectFilled(footMin, footMax, IM_COL32(17, 23, 27, 230), 6.0f * uiScale);
    draw->AddRect(footMin, footMax, goldDim, 6.0f * uiScale, 0, 1.3f * uiScale);
    runtime_preview_menu::IconCenter(draw, iconFont, (F107 ? 12.0f : 10.0f) * uiScale, ImVec2(footMin.x + 16.0f * uiScale, footMin.y + (footMax.y - footMin.y) * 0.5f), gold, ICON_FA_CLOCK);
    const float hintSize = textFont->FontSize * 1.04f * uiScale;
    const ImVec2 hintText = textFont->CalcTextSizeA(hintSize, FLT_MAX, 0.0f, hint);
    draw->AddText(textFont, hintSize, ImVec2(footMin.x + 36.0f * uiScale, footMin.y + (footMax.y - footMin.y - hintText.y) * 0.5f), IM_COL32(246, 247, 250, 255), hint);

    ImGui::Dummy(ImVec2(w, h));
}

inline void StatusShield(float uiScale)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    runtime_preview_menu::IconCenter(draw, iconFont, (F107 ? 15.0f : 13.0f) * uiScale, ImVec2(p.x + 12.0f * uiScale, p.y + 14.0f * uiScale), Theme::GetAccentTintU32(1.0f, 0.95f), ICON_FA_HEARTBEAT);
    draw->AddText(textFont, textFont->FontSize * 0.90f * uiScale, ImVec2(p.x + 32.0f * uiScale, p.y - 1.0f * uiScale), IM_COL32(240, 243, 248, 255), "SYSTEM STATUS");
    const ImVec2 center(p.x + w * 0.5f, p.y + 88.0f * uiScale);
    for (int i = 0; i < 4; ++i)
        draw->AddCircle(center, (49.0f + i * 5.0f) * uiScale, IM_COL32(255, 255, 255, 22 - i * 3), 48, 1.0f * uiScale);
    draw->AddCircle(center, 55.0f * uiScale, Theme::GetAccentTintU32(1.0f, 0.86f), 64, 3.0f * uiScale);
    const float shieldSize = (F107 ? 39.0f : 34.0f) * uiScale;
    const ImVec2 shieldText = iconFont->CalcTextSizeA(shieldSize, FLT_MAX, 0.0f, ICON_FA_SHIELD);
    draw->AddText(iconFont, shieldSize, center - shieldText * 0.5f, Theme::GetAccentTintU32(1.0f, 1.0f), ICON_FA_SHIELD);
    const char *protectedText = "Protected";
    const ImVec2 protectedSize = textFont->CalcTextSizeA(textFont->FontSize * 1.0f * uiScale, FLT_MAX, 0.0f, protectedText);
    draw->AddText(textFont, textFont->FontSize * 1.0f * uiScale, ImVec2(center.x - protectedSize.x * 0.5f, p.y + 156.0f * uiScale), IM_COL32(82, 230, 95, 255), protectedText);
    ImGui::Dummy(ImVec2(w, 195.0f * uiScale));
    Info("Driver", "Online", IM_COL32(82, 230, 95, 255), ICON_FA_CIRCLE);
    Info("Services", "Running", IM_COL32(82, 230, 95, 255), ICON_FA_CIRCLE);
    Info("Module", "Loaded", IM_COL32(82, 230, 95, 255), ICON_FA_CIRCLE);
}

inline void PerformanceTitle(float uiScale)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    draw->AddText(iconFont, (F107 ? 15.0f : 13.0f) * uiScale, ImVec2(p.x, p.y + 1.0f * uiScale), Theme::GetAccentTintU32(1.0f, 0.95f), ICON_FA_SIGNAL);
    draw->AddText(textFont, textFont->FontSize * 0.84f * uiScale, ImVec2(p.x + 26.0f * uiScale, p.y), IM_COL32(230, 233, 241, 245), "PERFORMANCE");
    ImGui::Dummy(ImVec2(ImGui::GetContentRegionAvail().x, 28.0f * uiScale));
}

inline void PerfRow(const char *label, const char *value, float ratio, float uiScale)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    const float labelSize = textFont->FontSize * 0.72f * uiScale;
    draw->AddText(textFont, labelSize, ImVec2(p.x, p.y), IM_COL32(190, 194, 206, 245), label);
    const ImVec2 vs = textFont->CalcTextSizeA(labelSize, FLT_MAX, 0.0f, value);
    draw->AddText(textFont, labelSize, ImVec2(p.x + w - vs.x, p.y), IM_COL32(220, 224, 234, 245), value);
    const ImVec2 barMin(p.x, p.y + 26.0f * uiScale);
    const ImVec2 barMax(p.x + w, p.y + 34.0f * uiScale);
    draw->AddRectFilled(barMin, barMax, IM_COL32(28, 29, 34, 235), 4.0f * uiScale);
    draw->AddRectFilled(barMin, ImVec2(barMin.x + w * ImClamp(ratio, 0.0f, 1.0f), barMax.y), Theme::GetAccentTintU32(1.0f, 0.95f), 4.0f * uiScale);
    ImGui::Dummy(ImVec2(w, 50.0f * uiScale));
}

inline void ConfigButton(const char *id, const char *icon, const char *title, const char *subtitle, const ImVec2 &size, float uiScale, bool danger);
inline bool ResetDefaultsCard(float uiScale, const ImVec2 &size);

inline void MetricCard(const char *icon, const char *label, const char *value, float ratio, float uiScale, const ImVec2 &size)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    const bool response = std::strcmp(label, "RESPONSE TIME") == 0;
    const ImU32 graphCol = response ? IM_COL32(116, 220, 72, 255) : Theme::GetAccentTintU32(1.0f, 1.0f);
    draw->AddRectFilled(p, p + size, IM_COL32(17, 23, 27, 246), 8.0f * uiScale);
    draw->AddRect(p, p + size, IM_COL32(154, 160, 170, 64), 8.0f * uiScale, 0, 1.6f * uiScale);
    const ImVec2 center(p.x + 40.0f * uiScale, p.y + size.y * 0.50f);
    const float arcR = 36.0f * uiScale;
    static float metricStart = 0.0f;
    if (metricStart <= 0.0f)
        metricStart = (float)ImGui::GetTime();
    const float elapsed = (float)ImGui::GetTime() - metricStart;
    const bool memory = std::strcmp(label, "MEMORY USAGE") == 0;
    const float finalArc = response ? 0.54f : (memory ? 0.68f : 0.82f);
    const float delay = response ? 2.0f : (memory ? 1.0f : 0.0f);
    const float local = ImClamp((elapsed - delay) / 1.0f, 0.0f, 1.0f);
    const float ease = local * local * (3.0f - 2.0f * local);
    const float staged = ImLerp(0.01f, finalArc, ease);
    ImVec2 trackPts[58];
    const int trackCount = 50;
    const float trackStart = -IM_PI * 0.62f;
    const float trackSweep = IM_PI * 1.72f;
    for (int i = 0; i < trackCount; ++i) {
        const float t = (float)i / (float)(trackCount - 1);
        const float a = trackStart + t * trackSweep;
        trackPts[i] = ImVec2(center.x + cosf(a) * arcR, center.y + sinf(a) * arcR);
    }
    draw->AddPolyline(trackPts, trackCount, IM_COL32(154, 160, 170, 42), false, 2.0f * uiScale);
    ImVec2 arcPts[64];
    const int arcCount = ImMax(3, (int)(staged * 60.0f));
    for (int i = 0; i < arcCount; ++i) {
        const float t = (float)i / (float)(arcCount - 1);
        const float a = trackStart + t * trackSweep * staged;
        arcPts[i] = ImVec2(center.x + cosf(a) * arcR, center.y + sinf(a) * arcR);
    }
    draw->AddPolyline(arcPts, arcCount, graphCol & IM_COL32(255, 255, 255, 150), false, 2.6f * uiScale);
    runtime_preview_menu::IconCenter(draw, iconFont, (F107 ? 22.0f : 18.0f) * uiScale, center, graphCol, icon);
    draw->AddText(textFont, textFont->FontSize * 0.78f * uiScale, ImVec2(p.x + 86.0f * uiScale, p.y + 17.0f * uiScale), IM_COL32(202, 207, 218, 245), label);
    draw->AddText(textFont, textFont->FontSize * 1.44f * uiScale, ImVec2(p.x + 86.0f * uiScale, p.y + 43.0f * uiScale), IM_COL32(245, 247, 250, 255), value);
    const char *trend = response ? value : (ratio > 0.2f ? "3%" : "2%");
    draw->AddText(textFont, textFont->FontSize * 0.70f * uiScale, ImVec2(p.x + 88.0f * uiScale, p.y + 83.0f * uiScale), graphCol, trend);
    const float graphY = p.y + size.y - 28.0f * uiScale;
    const float graphX = p.x + 12.0f * uiScale;
    const float graphW = size.x - 24.0f * uiScale;
        ImVec2 pts[13];
        for (int i = 0; i < 13; ++i) {
            const float t = (float)i / 12.0f;
            const float seed = response ? 1.9f : (ratio > 0.2f ? 1.1f : 0.4f);
        const float wave = (sinf(t * 7.4f + seed) * 5.0f + cosf(t * 13.0f) * 2.4f) * uiScale;
        const float lift = response ? t * 15.0f : t * (11.0f + ratio * 23.0f);
        pts[i] = ImVec2(graphX + graphW * t, graphY + wave - lift * uiScale);
    }
    draw->AddPolyline(pts, 13, graphCol, false, 1.8f * uiScale);
    draw->AddText(textFont, textFont->FontSize * 0.68f * uiScale, ImVec2(p.x + size.x - 66.0f * uiScale, p.y + size.y - 25.0f * uiScale), graphCol, response ? "Excellent" : "Good");
    ImGui::Dummy(size);
}

inline void ActivityPanel(float uiScale)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 start = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    struct Row { const char *title; const char *hint; };
    Row rows[] = {
        {"System initialized", "All systems operational"},
        {"Driver loaded", "Kernel driver successfully loaded"},
        {"Services started", "All services are running"},
        {"Protection enabled", "Anti-detection module active"},
    };
    static float activityStart = 0.0f;
    if (activityStart <= 0.0f)
        activityStart = (float)ImGui::GetTime();
    const float elapsed = (float)ImGui::GetTime() - activityStart;
    const char *title = "RECENT ACTIVITY";
    const float titleSize = textFont->FontSize * 1.12f * uiScale;
    draw->AddText(textFont, titleSize, ImVec2(start.x + 14.0f * uiScale, start.y + 11.0f * uiScale), IM_COL32(246, 247, 250, 255), title);
    draw->AddLine(ImVec2(start.x + 12.0f * uiScale, start.y + 40.0f * uiScale), ImVec2(start.x + w - 12.0f * uiScale, start.y + 40.0f * uiScale), IM_COL32(154, 160, 170, 95), 1.2f * uiScale);
    ImGui::Dummy(ImVec2(w, 54.0f * uiScale));
    const float rowH = ImMax(54.0f * uiScale, (ImGui::GetContentRegionAvail().y - 16.0f * uiScale) / (float)IM_ARRAYSIZE(rows));
    for (int i = 0; i < IM_ARRAYSIZE(rows); ++i) {
        const ImVec2 p = ImGui::GetCursorScreenPos();
        const float rowAppear = elapsed - (float)(i + 1) * 0.75f;
        const float alphaT = ImClamp(rowAppear / 0.14f, 0.0f, 1.0f);
        const ImVec2 iconCenter(p.x + 25.0f * uiScale, p.y + rowH * 0.5f);
        const float rowTitleSize = textFont->FontSize * 1.04f * uiScale;
        const float rowHintSize = textFont->FontSize * 0.84f * uiScale;
        const ImVec2 rowTitle = textFont->CalcTextSizeA(rowTitleSize, FLT_MAX, 0.0f, rows[i].title);
        const ImVec2 rowHint = textFont->CalcTextSizeA(rowHintSize, FLT_MAX, 0.0f, rows[i].hint);
        const float textY = p.y + (rowH - rowTitle.y - rowHint.y - 4.0f * uiScale) * 0.5f;
        if (alphaT > 0.0f) {
            const int a = (int)(alphaT * 255.0f);
            const int bgA = (int)(alphaT * 150.0f);
            draw->AddCircleFilled(iconCenter, 17.5f * uiScale, IM_COL32(244, 194, 84, bgA), 24);
            runtime_preview_menu::IconCenter(draw, iconFont, (F107 ? 16.0f : 14.0f) * uiScale, iconCenter, IM_COL32(255, 255, 255, a), ICON_FA_CHECK);
            draw->AddText(textFont, rowTitleSize, ImVec2(p.x + 56.0f * uiScale, textY), IM_COL32(242, 244, 250, a), rows[i].title);
            draw->AddText(textFont, rowHintSize, ImVec2(p.x + 56.0f * uiScale, textY + rowTitle.y + 4.0f * uiScale), IM_COL32(164, 170, 184, (int)(alphaT * 240.0f)), rows[i].hint);
        }
        ImGui::Dummy(ImVec2(w, rowH));
    }
}

inline void AnnouncementsPanel(float uiScale)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const float w = ImGui::GetContentRegionAvail().x;
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    draw->AddRectFilled(p + ImVec2(0.0f, 12.0f) * uiScale, p + ImVec2(62.0f, 76.0f) * uiScale, Theme::GetAccentTintU32(0.30f, 0.38f), 8.0f * uiScale);
    draw->AddText(iconFont, (F107 ? 31.0f : 25.0f) * uiScale, p + ImVec2(17.0f, 28.0f) * uiScale, Theme::GetAccentTintU32(1.0f, 1.0f), ICON_FA_SIGNAL);
    draw->AddText(textFont, textFont->FontSize * 0.84f * uiScale, ImVec2(p.x + 84.0f * uiScale, p.y + 14.0f * uiScale), IM_COL32(245, 247, 250, 255), "Update v41.0.0");
    draw->AddText(textFont, textFont->FontSize * 0.64f * uiScale, ImVec2(p.x + 84.0f * uiScale, p.y + 38.0f * uiScale), IM_COL32(170, 176, 190, 245), "We've improved performance, stability,");
    draw->AddText(textFont, textFont->FontSize * 0.64f * uiScale, ImVec2(p.x + 84.0f * uiScale, p.y + 56.0f * uiScale), IM_COL32(170, 176, 190, 245), "and added new features.");
    draw->AddText(textFont, textFont->FontSize * 0.66f * uiScale, ImVec2(p.x + 4.0f * uiScale, p.y + 104.0f * uiScale), Theme::GetAccentTintU32(1.0f, 1.0f), "v39.5.0");
    draw->AddText(textFont, textFont->FontSize * 0.70f * uiScale, ImVec2(p.x + 86.0f * uiScale, p.y + 104.0f * uiScale), IM_COL32(245, 247, 250, 255), "Hotfix");
    draw->AddText(textFont, textFont->FontSize * 0.62f * uiScale, ImVec2(p.x + 86.0f * uiScale, p.y + 126.0f * uiScale), IM_COL32(170, 176, 190, 245), "Fixed minor issues and improved compatibility.");
    ImGui::Dummy(ImVec2(w, 156.0f * uiScale));
}

inline void QuickActionsPanel(float uiScale)
{
    const float w = ImGui::GetContentRegionAvail().x;
    const float gap = 13.0f * uiScale;
    const float btnH = 70.0f * uiScale;
    ImDrawList *draw = ImGui::GetWindowDrawList();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImVec2 p = ImGui::GetCursorScreenPos();
    const char *title = "QUICK ACTIONS";
    draw->AddText(iconFont, (F107 ? 18.0f : 15.0f) * uiScale, ImVec2(p.x + 16.0f * uiScale, p.y + 14.0f * uiScale), Theme::GetAccentTintU32(1.0f, 1.0f), ICON_FA_BOLT);
    draw->AddText(textFont, textFont->FontSize * 1.16f * uiScale, ImVec2(p.x + 48.0f * uiScale, p.y + 9.0f * uiScale), IM_COL32(246, 247, 250, 255), title);
    p.y += 50.0f * uiScale;

    if (runtime_preview_menu::QuickActionCard(draw, iconFont, textFont, "v41_load_big", ICON_FA_FOLDER_OPEN, "LOAD CONFIG", "Load a configuration file", p, w, btnH, uiScale)) {
        LoadConfig();
        LoadConfiguration("astral_config");
    }
    p.y += btnH + gap;
    if (runtime_preview_menu::QuickActionCard(draw, iconFont, textFont, "v41_save_big", ICON_FA_SAVE, "SAVE CONFIG", "Save current configuration", p, w, btnH, uiScale)) {
        SaveConfig();
        SaveConfiguration("astral_config");
    }
    p.y += btnH + gap;
    if (runtime_preview_menu::QuickActionCard(draw, iconFont, textFont, "home_reset_guest_big", ICON_FA_SYNC, "RESET GUEST", "Revert all settings to defaults", p, w, btnH, uiScale)) {
        ResetBannedGuestAccount();
    }
}

inline void ConfigButton(const char *id, const char *icon, const char *title, const char *subtitle, const ImVec2 &size, float uiScale, bool danger = false)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton(id, size);
    const bool hovered = ImGui::IsItemHovered();
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    draw->AddRectFilled(p, p + size, ImGui::GetColorU32(hovered ? c::raspody::widget_hover : c::raspody::child), 20.0f * uiScale);
    const ImU32 color = danger ? IM_COL32(255, 60, 70, 255) : IM_COL32(238, 240, 246, 255);
    draw->AddText(iconFont, (F107 ? 23.0f : 19.0f) * uiScale, ImVec2(p.x + 26.0f * uiScale, p.y + (size.y - 23.0f * uiScale) * 0.5f), danger ? color : ImGui::GetColorU32(c::raspody::accent), icon);
    draw->AddText(textFont, textFont->FontSize * 0.78f * uiScale, ImVec2(p.x + 64.0f * uiScale, p.y + 19.0f * uiScale), color, title);
    if (subtitle && subtitle[0])
        draw->AddText(textFont, textFont->FontSize * 0.62f * uiScale, ImVec2(p.x + 64.0f * uiScale, p.y + 46.0f * uiScale), IM_COL32(170, 174, 188, 235), subtitle);
}

inline bool ResetDefaultsCard(float uiScale, const ImVec2 &size)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("home_reset_guest", size);
    const bool hovered = ImGui::IsItemHovered();
    const bool clicked = ImGui::IsItemClicked();
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();

    draw->AddRectFilled(p, p + size, ImGui::GetColorU32(hovered ? c::raspody::widget_hover : c::raspody::child), 20.0f * uiScale);
    draw->AddText(iconFont, (F107 ? 15.0f : 13.0f) * uiScale, ImVec2(p.x + 27.0f * uiScale, p.y + (size.y - 14.0f * uiScale) * 0.5f), IM_COL32(235, 237, 244, 255), ICON_FA_TH);

    const ImVec2 refreshBox(p.x + 76.0f * uiScale, p.y + 14.0f * uiScale);
    draw->AddRectFilled(refreshBox, refreshBox + ImVec2(44.0f, size.y / uiScale - 28.0f) * uiScale, IM_COL32(14, 15, 19, 255), 5.0f * uiScale);
    draw->AddRect(refreshBox, refreshBox + ImVec2(44.0f, size.y / uiScale - 28.0f) * uiScale, ImGui::GetColorU32(c::raspody::separator), 5.0f * uiScale, 0, 1.0f * uiScale);
    draw->AddText(iconFont, (F107 ? 17.0f : 14.0f) * uiScale, refreshBox + ImVec2(13.0f, 13.0f) * uiScale, IM_COL32(235, 237, 244, 255), ICON_FA_SYNC);

    const float sepX = p.x + 144.0f * uiScale;
    draw->AddLine(ImVec2(sepX, p.y + 11.0f * uiScale), ImVec2(sepX, p.y + size.y - 11.0f * uiScale), IM_COL32(198, 202, 214, 100), 1.45f * uiScale);
    draw->AddText(textFont, textFont->FontSize * 0.76f * uiScale, ImVec2(p.x + 132.0f * uiScale, p.y + 16.0f * uiScale), IM_COL32(235, 237, 244, 255), "RESET GUEST");
    draw->AddText(textFont, textFont->FontSize * 0.56f * uiScale, ImVec2(p.x + 132.0f * uiScale, p.y + 39.0f * uiScale), IM_COL32(178, 182, 194, 235), "Revert settings");
    draw->AddText(iconFont, (F107 ? 13.0f : 11.0f) * uiScale, ImVec2(p.x + size.x - 30.0f * uiScale, p.y + (size.y - 12.0f * uiScale) * 0.5f), IM_COL32(235, 237, 244, 255), ICON_FA_CHEVRON_RIGHT);
    return clicked;
}

inline bool QuickTogglesPanel(bool *clearDisplay, float uiScale)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    const float gap = 10.0f * uiScale;
    const float rowH = 72.0f * uiScale;
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();

    const ImVec2 clearMin = p;
    if (runtime_preview_menu::QuickToggleCard(draw, clearMin, ImVec2(w, rowH), "quick_clear_card", uiScale) && clearDisplay)
        *clearDisplay = !*clearDisplay;
    draw->AddText(iconFont, (F107 ? 18.0f : 15.0f) * uiScale, clearMin + ImVec2(22.0f, 24.0f) * uiScale, Theme::GetAccentTintU32(1.0f, 1.0f), ICON_FA_DESKTOP);
    draw->AddText(textFont, textFont->FontSize * 0.90f * uiScale, clearMin + ImVec2(64.0f, 15.0f) * uiScale, IM_COL32(245, 246, 250, 255), "Clear Display");
    draw->AddText(textFont, textFont->FontSize * 0.70f * uiScale, clearMin + ImVec2(64.0f, 40.0f) * uiScale, IM_COL32(178, 182, 194, 235), "Removes all visual clutter");

    const bool on = clearDisplay && *clearDisplay;
    const ImVec2 toggleMin(clearMin.x + w - 72.0f * uiScale, clearMin.y + 23.0f * uiScale);
    draw->AddRectFilled(toggleMin, toggleMin + ImVec2(56.0f, 25.0f) * uiScale, ImGui::GetColorU32(c::field_bg), 13.0f * uiScale);
    draw->AddRect(toggleMin, toggleMin + ImVec2(56.0f, 25.0f) * uiScale, Theme::GetAccentTintU32(1.0f, 0.56f), 13.0f * uiScale, 0, 1.35f * uiScale);
    draw->AddCircleFilled(ImVec2(toggleMin.x + (on ? 43.0f : 13.0f) * uiScale, toggleMin.y + 12.5f * uiScale), 10.0f * uiScale, IM_COL32(245, 246, 250, 255), 24);
    if (on) {
        const ImVec2 check = ImVec2(toggleMin.x + 38.0f * uiScale, toggleMin.y + 7.5f * uiScale);
        draw->AddLine(check, check + ImVec2(4.0f, 5.0f) * uiScale, IM_COL32(20, 22, 25, 255), 2.0f * uiScale);
        draw->AddLine(check + ImVec2(4.0f, 5.0f) * uiScale, check + ImVec2(11.0f, -2.0f) * uiScale, IM_COL32(20, 22, 25, 255), 2.0f * uiScale);
    }

    const ImVec2 accentMin(p.x, p.y + rowH + gap);
    if (runtime_preview_menu::QuickToggleCard(draw, accentMin, ImVec2(w, rowH), "quick_accent_card", uiScale)) {
        Theme::g_menuHue += 0.22f;
        if (Theme::g_menuHue > 1.0f) Theme::g_menuHue -= 1.0f;
        Theme::ApplyAccentFromHue();
    }
    const ImVec2 pickerMin = accentMin + ImVec2(13.0f, 16.0f) * uiScale;
    draw->AddRectFilled(pickerMin, pickerMin + ImVec2(36.0f, 36.0f) * uiScale, Theme::GetAccentU32(), 4.0f * uiScale);
    draw->AddRect(pickerMin, pickerMin + ImVec2(36.0f, 36.0f) * uiScale, Theme::GetAccentTintU32(1.0f, 0.70f), 4.0f * uiScale, 0, 1.35f * uiScale);
    draw->AddText(textFont, textFont->FontSize * 0.90f * uiScale, accentMin + ImVec2(64.0f, 15.0f) * uiScale, IM_COL32(245, 246, 250, 255), "Accent Color");
    draw->AddText(textFont, textFont->FontSize * 0.70f * uiScale, accentMin + ImVec2(64.0f, 40.0f) * uiScale, IM_COL32(178, 182, 194, 235), "Choose your menu accent");
    draw->AddText(iconFont, (F107 ? 15.0f : 12.0f) * uiScale, ImVec2(accentMin.x + w - 34.0f * uiScale, accentMin.y + 28.0f * uiScale), IM_COL32(245, 246, 250, 255), ICON_FA_CHEVRON_DOWN);
    ImGui::SetCursorScreenPos(ImVec2(p.x, accentMin.y + rowH + 1.0f * uiScale));
    return false;
}

inline void GlanceTile(const char *icon, const char *label, const char *value, float uiScale, float width = 0.0f)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const ImVec2 size = ImVec2(width > 0.0f ? width : ImGui::GetContentRegionAvail().x, 50.0f * uiScale);
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    draw->AddRectFilled(p, p + size, IM_COL32(10, 11, 15, 245), 5.0f * uiScale);
    draw->AddRect(p, p + size, IM_COL32(42, 43, 50, 225), 5.0f * uiScale);
    draw->AddText(iconFont, (F107 ? 18.0f : 15.0f) * uiScale, ImVec2(p.x + 16.0f * uiScale, p.y + 14.0f * uiScale), IM_COL32(220, 224, 234, 245), icon);
    draw->AddText(textFont, textFont->FontSize * 0.62f * uiScale, ImVec2(p.x + 48.0f * uiScale, p.y + 9.0f * uiScale), IM_COL32(150, 154, 168, 235), label);
    draw->AddText(textFont, textFont->FontSize * 0.76f * uiScale, ImVec2(p.x + 48.0f * uiScale, p.y + 27.0f * uiScale), IM_COL32(235, 237, 244, 255), value);
    ImGui::Dummy(size);
}

inline void Accent()
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    const ImVec2 size(w, 43.0f);
    ImGui::InvisibleButton("##accent_color_row", size);
    if (ImGui::IsItemClicked()) {
        Theme::g_menuHue += 0.22f;
        if (Theme::g_menuHue > 1.0f) Theme::g_menuHue -= 1.0f;
        Theme::ApplyAccentFromHue();
    }
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    draw->AddText(iconFont, F107 ? 14.0f : 12.0f, ImVec2(p.x + 8.0f, p.y + 12.0f), IM_COL32(205, 210, 224, 245), ICON_FA_CIRCLE_NOTCH);
    draw->AddText(textFont, textFont->FontSize * 0.82f, ImVec2(p.x + 40.0f, p.y + 7.0f), IM_COL32(232, 233, 240, 255), "Accent Color");
    draw->AddText(textFont, textFont->FontSize * 0.72f, ImVec2(p.x + 40.0f, p.y + 24.0f), IM_COL32(150, 154, 168, 245), "Choose your menu accent");
    const ImVec2 swatchMin(p.x + w - 84.0f, p.y + 6.0f);
    draw->AddRectFilled(swatchMin, swatchMin + ImVec2(40.0f, 31.0f), Theme::GetAccentU32(), 4.0f);
    draw->AddText(iconFont, F107 ? 14.0f : 12.0f, ImVec2(p.x + w - 33.0f, p.y + 13.0f), Theme::GetAccentTintU32(1.0f, 1.0f), ICON_FA_CHEVRON_DOWN);
}

inline bool ResetGuest(bool *)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const float w = ImGui::GetContentRegionAvail().x;
    const ImVec2 rowSize(w, 43.0f);
    const ImVec2 buttonSize(84.0f, 34.0f);
    const ImVec2 buttonMin(p.x + w - buttonSize.x - 8.0f, p.y + (rowSize.y - buttonSize.y) * 0.5f);
    const ImVec2 buttonMax = buttonMin + buttonSize;

    ImGui::InvisibleButton("##reset_guest_row", rowSize);
    const bool rowHovered = ImGui::IsItemHovered();
    ImGui::SetCursorScreenPos(buttonMin);
    ImGui::InvisibleButton("##reset_guest_button", buttonSize);
    const bool hovered = ImGui::IsItemHovered();
    const bool held = ImGui::IsItemActive();
    const bool clicked = ImGui::IsItemClicked();

    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    ImFont *textFont = font::inter_semibold ? font::inter_semibold : ImGui::GetFont();
    const ImU32 labelColor = rowHovered ? IM_COL32(245, 246, 252, 255) : IM_COL32(232, 233, 240, 255);
    const ImU32 hintColor = IM_COL32(150, 154, 168, 245);
    const ImU32 red = held ? IM_COL32(255, 88, 104, 255) : hovered ? IM_COL32(255, 70, 86, 255) : IM_COL32(255, 45, 64, 255);

    draw->AddText(iconFont, F107 ? 14.0f : 12.0f, ImVec2(p.x + 8.0f, p.y + 12.0f), IM_COL32(205, 210, 224, 245), ICON_FA_CIRCLE_NOTCH);
    draw->AddText(textFont, textFont->FontSize * 0.82f, ImVec2(p.x + 40.0f, p.y + 7.0f), labelColor, "Reset Guest");
    draw->AddText(textFont, textFont->FontSize * 0.72f, ImVec2(p.x + 40.0f, p.y + 24.0f), hintColor, "Reset guest data and settings");
    draw->AddRectFilled(buttonMin, buttonMax, hovered ? IM_COL32(34, 18, 24, 230) : IM_COL32(13, 14, 19, 230), 5.0f);
    draw->AddRect(buttonMin, buttonMax, red, 5.0f, 0, 1.7f);

    const char *text = "RESET";
    const float textSize = textFont->FontSize * 0.74f;
    const ImVec2 ts = textFont->CalcTextSizeA(textSize, FLT_MAX, 0.0f, text);
    draw->AddText(textFont, textSize, buttonMin + ImVec2((buttonSize.x - ts.x) * 0.5f, (buttonSize.y - ts.y) * 0.5f), red, text);
    return clicked;
}

inline void VisualPreview(bool box, bool skeleton, bool health, bool name, bool distance, int boxType = 0, int lineTarget = 0, int healthPosition = 0)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    const ImVec2 size = ImGui::GetContentRegionAvail();
    const ImVec2 max = p + size;
    draw->AddRectFilled(p, max, ImGui::GetColorU32(c::field_bg), 5.0f);
    draw->AddRectFilledMultiColor(p, max, IM_COL32(20, 20, 28, 238), IM_COL32(17, 17, 24, 242), IM_COL32(22, 19, 31, 245), IM_COL32(25, 21, 36, 240));
    draw->AddRect(p, max, Theme::GetAccentTintU32(1.0f, 0.34f), 5.0f, 0, 1.25f);
    const ImVec2 radarCenter((p.x + max.x) * 0.5f, (p.y + max.y) * 0.52f);
    const float radarR = ImMin(size.x, size.y) * 0.34f;
    draw->AddCircle(radarCenter, radarR, Theme::GetAccentTintU32(1.0f, 0.14f), 72, 1.0f);
    draw->AddCircle(radarCenter, radarR * 0.64f, Theme::GetAccentTintU32(1.0f, 0.12f), 72, 1.0f);
    draw->AddLine(ImVec2(radarCenter.x - radarR, radarCenter.y), ImVec2(radarCenter.x + radarR, radarCenter.y), Theme::GetAccentTintU32(1.0f, 0.09f), 1.0f);
    draw->AddLine(ImVec2(radarCenter.x, radarCenter.y - radarR), ImVec2(radarCenter.x, radarCenter.y + radarR), Theme::GetAccentTintU32(1.0f, 0.09f), 1.0f);

    const float topPad = 10.0f;
    const float bottomPad = 10.0f;
    const float labelH = 22.0f;
    const float labelGap = 7.0f;
    const float availableH = ImMax(40.0f, size.y - topPad - bottomPad - labelH * 2.0f - labelGap * 2.0f);
    const float bodyH = ImMin(availableH, size.x * 0.43f);
    const float bodyW = bodyH * 0.58f;
    const float groupH = labelH * 2.0f + labelGap * 2.0f + bodyH;
    const float groupTop = p.y + ImMax(topPad, (size.y - groupH) * 0.5f);
    const ImVec2 center((p.x + max.x) * 0.5f, groupTop + labelH + labelGap + bodyH * 0.5f);
    const ImVec2 boxMin(center.x - bodyW * 0.5f, center.y - bodyH * 0.5f);
    const ImVec2 boxMax(center.x + bodyW * 0.5f, center.y + bodyH * 0.5f);

    if (name) {
        const char *text = "NAME";
        const ImVec2 ts = ImGui::CalcTextSize(text);
        const float labelW = ImMax(bodyW + 28.0f, ts.x + 28.0f);
        const ImVec2 labelMin(center.x - labelW * 0.5f, groupTop);
        draw->AddRectFilled(labelMin, labelMin + ImVec2(labelW, labelH), ImGui::GetColorU32(c::panel_bg), 3.0f);
        draw->AddRect(labelMin, labelMin + ImVec2(labelW, labelH), Theme::GetAccentTintU32(1.0f, 0.42f), 3.0f, 0, 1.0f);
        draw->AddText(ImVec2(center.x - ts.x * 0.5f, labelMin.y + (labelH - ts.y) * 0.5f), IM_COL32(240, 240, 245, 255), text);
    }
    if (box) {
        const ImU32 border = Theme::GetAccentTintU32(1.0f, 0.82f);
        const ImU32 fill = Theme::GetAccentTintU32(1.0f, 0.10f);
        if (boxType == 0)
            draw->AddRectFilled(boxMin, boxMax, fill, 2.0f);
        if (boxType == 2 || boxType == 3) {
            const float corner = ImMin(bodyW * 0.30f, 26.0f);
            draw->AddLine(boxMin, ImVec2(boxMin.x + corner, boxMin.y), border, 2.0f);
            draw->AddLine(boxMin, ImVec2(boxMin.x, boxMin.y + corner), border, 2.0f);
            draw->AddLine(ImVec2(boxMax.x - corner, boxMin.y), ImVec2(boxMax.x, boxMin.y), border, 2.0f);
            draw->AddLine(ImVec2(boxMax.x, boxMin.y), ImVec2(boxMax.x, boxMin.y + corner), border, 2.0f);
            draw->AddLine(ImVec2(boxMin.x, boxMax.y - corner), ImVec2(boxMin.x, boxMax.y), border, 2.0f);
            draw->AddLine(ImVec2(boxMin.x, boxMax.y), ImVec2(boxMin.x + corner, boxMax.y), border, 2.0f);
            draw->AddLine(ImVec2(boxMax.x - corner, boxMax.y), boxMax, border, 2.0f);
            draw->AddLine(ImVec2(boxMax.x, boxMax.y - corner), boxMax, border, 2.0f);
        } else {
            draw->AddRect(boxMin, boxMax, border, 2.0f, 0, 2.0f);
        }
        if (boxType == 3) {
            const ImVec2 off(bodyW * 0.10f, -bodyH * 0.08f);
            draw->AddRect(boxMin + off, boxMax + off, Theme::GetAccentTintU32(1.0f, 0.38f), 2.0f, 0, 1.3f);
            draw->AddLine(boxMin, boxMin + off, Theme::GetAccentTintU32(1.0f, 0.34f), 1.2f);
            draw->AddLine(ImVec2(boxMax.x, boxMin.y), ImVec2(boxMax.x, boxMin.y) + off, Theme::GetAccentTintU32(1.0f, 0.34f), 1.2f);
        }
    }
    if (skeleton) {
        const float line = ImMax(1.4f, bodyH * 0.018f);
        const ImU32 bone = IM_COL32(228, 224, 255, 224);
        const ImU32 boneSoft = Theme::GetAccentTintU32(1.0f, 0.16f);
        const ImVec2 head(center.x, center.y - bodyH * 0.31f);
        const ImVec2 neck(center.x, center.y - bodyH * 0.19f);
        const ImVec2 chest(center.x, center.y - bodyH * 0.08f);
        const ImVec2 pelvis(center.x, center.y + bodyH * 0.10f);
        const ImVec2 leftShoulder(center.x - bodyW * 0.24f, center.y - bodyH * 0.14f);
        const ImVec2 rightShoulder(center.x + bodyW * 0.24f, center.y - bodyH * 0.14f);
        const ImVec2 leftElbow(center.x - bodyW * 0.35f, center.y + bodyH * 0.05f);
        const ImVec2 rightElbow(center.x + bodyW * 0.35f, center.y + bodyH * 0.05f);
        const ImVec2 leftHand(center.x - bodyW * 0.31f, center.y + bodyH * 0.25f);
        const ImVec2 rightHand(center.x + bodyW * 0.31f, center.y + bodyH * 0.25f);
        const ImVec2 leftKnee(center.x - bodyW * 0.16f, center.y + bodyH * 0.31f);
        const ImVec2 rightKnee(center.x + bodyW * 0.16f, center.y + bodyH * 0.31f);
        const ImVec2 leftFoot(center.x - bodyW * 0.20f, center.y + bodyH * 0.50f);
        const ImVec2 rightFoot(center.x + bodyW * 0.20f, center.y + bodyH * 0.50f);
        const ImU32 boneMid = Theme::GetAccentTintU32(1.0f, 0.26f);
        draw->AddCircle(head, bodyH * 0.105f, bone, 40, line);
        runtime_preview_menu::PreviewLimb(draw, neck, chest, line, boneSoft, boneMid, bone);
        runtime_preview_menu::PreviewLimb(draw, chest, pelvis, line, boneSoft, boneMid, bone);
        runtime_preview_menu::PreviewLimb(draw, leftShoulder, rightShoulder, line, boneSoft, boneMid, bone);
        runtime_preview_menu::PreviewLimb(draw, leftShoulder, leftElbow, line, boneSoft, boneMid, bone);
        runtime_preview_menu::PreviewLimb(draw, leftElbow, leftHand, line, boneSoft, boneMid, bone);
        runtime_preview_menu::PreviewLimb(draw, rightShoulder, rightElbow, line, boneSoft, boneMid, bone);
        runtime_preview_menu::PreviewLimb(draw, rightElbow, rightHand, line, boneSoft, boneMid, bone);
        runtime_preview_menu::PreviewLimb(draw, pelvis, leftKnee, line, boneSoft, boneMid, bone);
        runtime_preview_menu::PreviewLimb(draw, pelvis, rightKnee, line, boneSoft, boneMid, bone);
        runtime_preview_menu::PreviewLimb(draw, leftKnee, leftFoot, line, boneSoft, boneMid, bone);
        runtime_preview_menu::PreviewLimb(draw, rightKnee, rightFoot, line, boneSoft, boneMid, bone);
        draw->AddLine(ImVec2(center.x - bodyW * 0.13f, center.y + bodyH * 0.50f), ImVec2(center.x + bodyW * 0.13f, center.y + bodyH * 0.50f), Theme::GetAccentTintU32(1.0f, 0.22f), 1.2f);
    }
    if (health) {
        if (healthPosition == 0)
            draw->AddRectFilled(ImVec2(boxMin.x, boxMin.y - 8.0f), ImVec2(boxMax.x, boxMin.y - 4.0f), IM_COL32(43, 214, 140, 255), 2.0f);
        else
            draw->AddRectFilled(ImVec2(boxMin.x - 18.0f, boxMin.y), ImVec2(boxMin.x - 13.0f, boxMax.y), IM_COL32(43, 214, 140, 255), 2.0f);
    }
    if (distance) {
        const char *text = "DISTANCE";
        const ImVec2 ts = ImGui::CalcTextSize(text);
        const float labelW = ImMax(bodyW * 0.82f, ts.x + 22.0f);
        const ImVec2 labelMin(center.x - labelW * 0.5f, boxMax.y + labelGap);
        draw->AddRectFilled(labelMin, labelMin + ImVec2(labelW, labelH), ImGui::GetColorU32(c::panel_bg), 3.0f);
        draw->AddRect(labelMin, labelMin + ImVec2(labelW, labelH), Theme::GetAccentTintU32(1.0f, 0.42f), 3.0f, 0, 1.0f);
        draw->AddText(ImVec2(center.x - ts.x * 0.5f, labelMin.y + (labelH - ts.y) * 0.5f), IM_COL32(240, 240, 245, 255), text);
    }
    if (lineTarget >= 0) {
        const float anchorY = lineTarget == 0 ? p.y + 8.0f : (lineTarget == 1 ? center.y : max.y - 8.0f);
        draw->AddLine(ImVec2((p.x + max.x) * 0.5f, anchorY), ImVec2(center.x, boxMin.y), Theme::GetAccentTintU32(1.0f, 0.46f), 1.2f);
    }
    ImGui::Dummy(size);
}

struct HomeLayout {
    float gap;
    float cardH;
    float cardW;
    float middleH;
    float colW;
    float bottomH;
    ImVec2 cardSize;
    ImVec2 middleSize;
    ImVec2 bottomSize;
    ImVec2 versionPos;
    ImVec2 buildPos;
    ImVec2 licensePos;
    ImVec2 quickPos;
    ImVec2 systemPos;
    ImVec2 developerPos;
    ImVec2 gamePos;
};

inline HomeLayout HomeGrid(const ImVec2 &contentRegion, float uiScale)
{
    HomeLayout layout{};
    layout.gap = 12.0f * uiScale;
    layout.cardH = 150.0f * uiScale;
    layout.cardW = ImMax(1.0f, (contentRegion.x - layout.gap * 2.0f) / 3.0f);
    layout.middleH = 242.0f * uiScale;
    layout.colW = ImMax(1.0f, (contentRegion.x - layout.gap) * 0.5f);
    layout.bottomH = ImMax(146.0f * uiScale, contentRegion.y - layout.cardH - layout.middleH - layout.gap * 2.0f - 4.0f * uiScale);
    layout.cardSize = ImVec2(layout.cardW, layout.cardH);
    layout.middleSize = ImVec2(layout.colW, layout.middleH);
    layout.bottomSize = ImVec2(layout.colW, layout.bottomH);
    layout.versionPos = ImGui::GetCursorScreenPos();
    layout.buildPos = ImVec2(layout.versionPos.x + layout.cardW + layout.gap, layout.versionPos.y);
    layout.licensePos = ImVec2(layout.versionPos.x + (layout.cardW + layout.gap) * 2.0f, layout.versionPos.y);
    layout.quickPos = ImVec2(layout.versionPos.x, layout.versionPos.y + layout.cardH + layout.gap);
    layout.systemPos = ImVec2(layout.quickPos.x + layout.colW + layout.gap, layout.quickPos.y);
    layout.developerPos = ImVec2(layout.quickPos.x, layout.quickPos.y + layout.middleH + layout.gap);
    layout.gamePos = ImVec2(layout.developerPos.x + layout.colW + layout.gap, layout.developerPos.y);
    return layout;
}

struct TwoColumnLayout {
    ImVec2 start;
    ImVec2 left;
    ImVec2 right;
    ImVec2 size;
};

inline TwoColumnLayout TwoColumns(float childWidth, float childHeight, float columnGap)
{
    TwoColumnLayout layout{};
    layout.start = ImGui::GetCursorScreenPos();
    layout.left = layout.start;
    layout.right = ImVec2(layout.start.x + childWidth + columnGap, layout.start.y);
    layout.size = ImVec2(childWidth, childHeight);
    return layout;
}

struct VisualLayout : TwoColumnLayout {
    float adjustableH;
    float previewH;
    ImVec2 adjustablePos;
    ImVec2 previewPos;
};

inline VisualLayout VisualGrid(float childWidth, float childHeight, float columnGap, float uiScale)
{
    VisualLayout layout{};
    const TwoColumnLayout base = TwoColumns(childWidth, childHeight, columnGap);
    layout.start = base.start;
    layout.left = base.left;
    layout.right = base.right;
    layout.size = base.size;
    layout.adjustableH = ImMin(300.0f * uiScale, ImMax(180.0f * uiScale, childHeight * 0.56f));
    layout.previewH = ImMax(110.0f * uiScale, childHeight - layout.adjustableH - columnGap);
    layout.adjustablePos = layout.right;
    layout.previewPos = ImVec2(layout.right.x, layout.right.y + layout.adjustableH + columnGap);
    return layout;
}

struct MemoryLayout : TwoColumnLayout {
    float battleH;
    float sliderH;
    ImVec2 battlePos;
    ImVec2 sliderPos;
};

inline MemoryLayout MemoryGrid(float childWidth, float childHeight, float columnGap)
{
    MemoryLayout layout{};
    const TwoColumnLayout base = TwoColumns(childWidth, childHeight, columnGap);
    layout.start = base.start;
    layout.left = base.left;
    layout.right = base.right;
    layout.size = base.size;
    layout.sliderH = ImMin(360.0f, ImMax(330.0f, childHeight * 0.53f));
    layout.battleH = childHeight - layout.sliderH - columnGap;
    if (layout.battleH < 210.0f) {
        layout.battleH = ImMax(170.0f, childHeight - 330.0f - columnGap);
        layout.sliderH = ImMax(310.0f, childHeight - layout.battleH - columnGap);
    }
    layout.battlePos = layout.right;
    layout.sliderPos = ImVec2(layout.right.x, layout.right.y + layout.battleH + columnGap);
    return layout;
}

struct MiscLayout {
    float gap;
    float leftW;
    float rightW;
    float height;
    ImVec2 leftPos;
    ImVec2 rightPos;
};

inline MiscLayout MiscGrid(const ImVec2 &contentRegion, float childHeight, float uiScale)
{
    MiscLayout layout{};
    layout.gap = 8.0f * uiScale;
    layout.leftW = ImMax(310.0f * uiScale, contentRegion.x * 0.48f);
    layout.rightW = ImMax(260.0f * uiScale, contentRegion.x - layout.leftW - layout.gap);
    layout.height = childHeight;
    layout.leftPos = ImGui::GetCursorScreenPos();
    layout.rightPos = ImVec2(layout.leftPos.x + layout.leftW + layout.gap, layout.leftPos.y);
    return layout;
}

struct RuntimeInfo {
    char resolution[64];
    std::string package;
    std::string os;
    std::string device;
    std::string memory;
};

inline RuntimeInfo CollectRuntimeInfo(const ImVec2 &displaySize)
{
    RuntimeInfo info{};
    std::snprintf(info.resolution, sizeof(info.resolution), "%.0f x %.0f", displaySize.x, displaySize.y);
    info.package = PackageName();
    info.os = OsVersion();
    info.device = DeviceName();
    info.memory = MemoryUsage();
    return info;
}

inline float MiscFilterWidth(float uiScale)
{
    return (ImGui::GetContentRegionAvail().x - 24.0f * uiScale) / 4.0f;
}

inline float PriceHeader(float uiScale)
{
    ImDrawList *draw = ImGui::GetWindowDrawList();
    const ImVec2 pos = ImGui::GetCursorScreenPos();
    const float width = ImGui::GetContentRegionAvail().x;
    draw->AddText(ImVec2(pos.x + 12.0f * uiScale, pos.y), Theme::GetAccentTintU32(1.0f, 0.95f), "PLAN");
    draw->AddText(ImVec2(pos.x + width * 0.34f, pos.y), Theme::GetAccentTintU32(1.0f, 0.95f), "LOCAL");
    draw->AddText(ImVec2(pos.x + width * 0.64f, pos.y), Theme::GetAccentTintU32(1.0f, 0.95f), "FOREIGN");
    ImGui::Dummy(ImVec2(width, 22.0f * uiScale));
    return width;
}

inline bool MiscFilterPill(const char *id, const char *icon, const char *label, bool active, const ImVec2 &size, ImU32 color, float uiScale)
{
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton(id, size);
    const bool clicked = ImGui::IsItemClicked();
    const bool hovered = ImGui::IsItemHovered();
    ImDrawList *dl = ImGui::GetWindowDrawList();
    const ImVec2 max(p.x + size.x, p.y + size.y);
    if (active)
        dl->AddRectFilledMultiColor(p, max, IM_COL32(244, 211, 94, 245), IM_COL32(202, 163, 64, 245), IM_COL32(138, 100, 21, 235), IM_COL32(202, 163, 64, 245));
    else
        dl->AddRectFilled(p, max, ImGui::GetColorU32(c::panel_bg), 5.0f * uiScale);
    dl->AddRect(p, max, active ? Theme::GetAccentTintU32(1.0f, 0.92f) : Theme::GetAccentTintU32(1.0f, 0.42f), 5.0f * uiScale, 0, active ? 1.8f * uiScale : 1.35f * uiScale);
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    const float iconSize = ImGui::GetFontSize() * 0.82f * uiScale;
    const float textSize = ImGui::GetFontSize() * 0.78f * uiScale;
    ImVec2 is = iconFont->CalcTextSizeA(iconSize, FLT_MAX, 0.0f, icon);
    ImVec2 ts = ImGui::GetFont()->CalcTextSizeA(textSize, FLT_MAX, 0.0f, label);
    const float x = p.x + (size.x - is.x - 8.0f * uiScale - ts.x) * 0.5f;
    if (icon && icon[0]) dl->AddText(iconFont, iconSize, ImVec2(x, p.y + (size.y - is.y) * 0.5f), active ? IM_COL32(255, 255, 255, 255) : color, icon);
    dl->AddText(ImGui::GetFont(), textSize, ImVec2(x + is.x + 8.0f * uiScale, p.y + (size.y - ts.y) * 0.5f), active ? IM_COL32(255, 255, 255, 255) : IM_COL32(210, 213, 224, 235), label);
    return clicked;
}

inline double &MiscListAnimStart()
{
    static double start = 0.0;
    return start;
}

inline double &PriceListAnimStart()
{
    static double start = 0.0;
    return start;
}

inline void ResetMiscListAnim()
{
    MiscListAnimStart() = ImGui::GetTime();
}

inline void MiscFeedItem(const char *kind, const char *body, const char *date, const char *icon, ImU32 color, float uiScale)
{
    (void)date;
    static int lastFrame = -1;
    static int itemIndex = 0;
    double &animStart = MiscListAnimStart();
    const int frame = ImGui::GetFrameCount();
    if (lastFrame != frame) {
        lastFrame = frame;
        itemIndex = 0;
    }
    if (animStart <= 0.0)
        animStart = ImGui::GetTime();
    const int currentIndex = itemIndex++;
    const float slideT = ImClamp(((float)(ImGui::GetTime() - animStart) - currentIndex * 0.075f) / 0.38f, 0.0f, 1.0f);
    const float ease = slideT * slideT * (3.0f - 2.0f * slideT);
    ImVec2 p = ImGui::GetCursorScreenPos();
    p.y += (1.0f - ease) * 18.0f * uiScale;
    const float w = ImGui::GetContentRegionAvail().x;
    const float h = 76.0f * uiScale;
    ImDrawList *dl = ImGui::GetWindowDrawList();
    const ImU32 border = (color & IM_COL32(255, 255, 255, 0)) | IM_COL32(0, 0, 0, (int)(128.0f * ease));
    const ImU32 textCol = IM_COL32(204, 209, 229, (int)(242.0f * ease));
    const ImU32 kindCol = (color & IM_COL32(255, 255, 255, 0)) | IM_COL32(0, 0, 0, (int)(255.0f * ease));
    dl->AddRectFilled(p, ImVec2(p.x + w, p.y + h), ImGui::GetColorU32(c::panel_bg), 7.0f * uiScale);
    dl->AddRect(p, ImVec2(p.x + w, p.y + h), border, 7.0f * uiScale, 0, 1.65f * uiScale);
    ImFont *iconFont = F107 ? F107 : ImGui::GetFont();
    runtime_preview_menu::IconCenter(dl, iconFont, ImGui::GetFontSize() * 1.0f * uiScale, ImVec2(p.x + 28.0f * uiScale, p.y + 28.0f * uiScale), kindCol, icon);
    dl->AddText(ImGui::GetFont(), ImGui::GetFontSize() * 0.92f * uiScale, ImVec2(p.x + 52.0f * uiScale, p.y + 12.0f * uiScale), kindCol, kind);
    dl->AddText(ImGui::GetFont(), ImGui::GetFontSize() * 0.96f * uiScale, ImVec2(p.x + 52.0f * uiScale, p.y + 34.0f * uiScale), textCol, body, nullptr, ImMax(120.0f, w - 70.0f * uiScale));
    ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + h + 8.0f * uiScale - (1.0f - ease) * 18.0f * uiScale));
}

inline void PriceRow(const char *plan, const char *peso, const char *price, float uiScale)
{
    static int lastFrame = -1;
    static int itemIndex = 0;
    const int frame = ImGui::GetFrameCount();
    if (lastFrame != frame) {
        lastFrame = frame;
        itemIndex = 0;
    }
    double &animStart = PriceListAnimStart();
    if (animStart <= 0.0)
        animStart = ImGui::GetTime();
    const int currentIndex = itemIndex++;
    const float slideT = ImClamp(((float)(ImGui::GetTime() - animStart) - currentIndex * 0.055f) / 0.32f, 0.0f, 1.0f);
    const float ease = slideT * slideT * (3.0f - 2.0f * slideT);
    ImVec2 p = ImGui::GetCursorScreenPos();
    p.y += (1.0f - ease) * 12.0f * uiScale;
    const float w = ImGui::GetContentRegionAvail().x;
    const float h = 35.0f * uiScale;
    ImDrawList *dl = ImGui::GetWindowDrawList();
    const int a = (int)(ease * 255.0f);
    dl->AddRectFilled(p, ImVec2(p.x + w, p.y + h), ImGui::GetColorU32(c::panel_bg), 7.0f * uiScale);
    dl->AddRect(p, ImVec2(p.x + w, p.y + h), Theme::GetAccentTintU32(1.0f, 0.45f * ease), 7.0f * uiScale, 0, 1.45f * uiScale);
    dl->AddText(ImVec2(p.x + 12.0f * uiScale, p.y + 10.0f * uiScale), IM_COL32(220, 224, 238, (int)(245.0f * ease)), plan);
    dl->AddText(ImVec2(p.x + w * 0.34f, p.y + 10.0f * uiScale), Theme::GetAccentTintU32(1.0f, 0.95f * ease), peso);
    dl->AddText(ImVec2(p.x + w * 0.64f, p.y + 10.0f * uiScale), IM_COL32(220, 224, 238, (int)(245.0f * ease)), price);
    const ImVec2 cartMin(p.x + w - 34.0f * uiScale, p.y + 5.0f * uiScale);
    const ImVec2 cartMax(p.x + w - 8.0f * uiScale, p.y + h - 5.0f * uiScale);
    dl->AddRectFilled(cartMin, cartMax, ImGui::GetColorU32(c::field_bg), 6.0f * uiScale);
    dl->AddRect(cartMin, cartMax, Theme::GetAccentTintU32(1.0f, 0.45f * ease), 6.0f * uiScale, 0, 1.35f * uiScale);
    ImFont *cartFont = F107 ? F107 : ImGui::GetFont();
    const char *cartGlyph = F107 ? ICON_FA_SHOPPING_CART : "$";
    const float cartSize = (F107 ? 13.0f : 12.0f) * uiScale;
    const ImVec2 cartText = cartFont->CalcTextSizeA(cartSize, FLT_MAX, 0.0f, cartGlyph);
    dl->AddText(cartFont, cartSize, ImVec2(cartMin.x + (cartMax.x - cartMin.x - cartText.x) * 0.5f, cartMin.y + (cartMax.y - cartMin.y - cartText.y) * 0.5f), IM_COL32(178, 184, 196, a), cartGlyph);
    ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + h + 8.0f * uiScale - (1.0f - ease) * 12.0f * uiScale));
}

