#pragma once

#ifndef IMGUI_DEFINE_MATH_OPERATORS
#define IMGUI_DEFINE_MATH_OPERATORS
#endif

#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"
#include "imgui_internal.h"

#include "Assets/Fonts/fontch.h"
#include "Assets/Fonts/auto_techno.h"
#include "Assets/Fonts/techno_hideo.h"
#include "Assets/Fonts/angas_v3_ultra.h"
#include "Assets/Fonts/Icon.h"
#include "Assets/Fonts/Iconcpp.h"
