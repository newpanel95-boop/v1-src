
#ifndef HEADER_COMP_H
# define HEADER_COMP_H

# include <openssl/opensslconf.h>

# ifndef OPENSSL_NO_COMP
# include <openssl/crypto.h>
# ifdef  __cplusplus
extern "C" {
# endif

COMP_CTX *COMP_CTX_new(COMP_METHOD *meth);
const COMP_METHOD *COMP_CTX_get_method(const COMP_CTX *ctx);
int COMP_CTX_get_type(const COMP_CTX* comp);
int COMP_get_type(const COMP_METHOD *meth);
const char *COMP_get_name(const COMP_METHOD *meth);
void COMP_CTX_free(COMP_CTX *ctx);

int COMP_compress_block(COMP_CTX *ctx, unsigned char *out, int olen,
                        unsigned char *in, int ilen);
int COMP_expand_block(COMP_CTX *ctx, unsigned char *out, int olen,
                      unsigned char *in, int ilen);

COMP_METHOD *COMP_zlib(void);

#if OPENSSL_API_COMPAT < 0x10100000L
#define COMP_zlib_cleanup() while(0) continue
#endif

# ifdef HEADER_BIO_H
#  ifdef ZLIB
const BIO_METHOD *BIO_f_zlib(void);
#  endif
# endif

int ERR_load_COMP_strings(void);

# define COMP_F_BIO_ZLIB_FLUSH                            99
# define COMP_F_BIO_ZLIB_NEW                              100
# define COMP_F_BIO_ZLIB_READ                             101
# define COMP_F_BIO_ZLIB_WRITE                            102

# define COMP_R_ZLIB_DEFLATE_ERROR                        99
# define COMP_R_ZLIB_INFLATE_ERROR                        100
# define COMP_R_ZLIB_NOT_SUPPORTED                        101

#  ifdef  __cplusplus
}
#  endif
# endif
#endif
