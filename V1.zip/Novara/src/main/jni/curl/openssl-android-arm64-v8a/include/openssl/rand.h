
#ifndef HEADER_RAND_H
# define HEADER_RAND_H

# include <stdlib.h>
# include <openssl/ossl_typ.h>
# include <openssl/e_os2.h>

#ifdef  __cplusplus
extern "C" {
#endif

struct rand_meth_st {
    int (*seed) (const void *buf, int num);
    int (*bytes) (unsigned char *buf, int num);
    void (*cleanup) (void);
    int (*add) (const void *buf, int num, double entropy);
    int (*pseudorand) (unsigned char *buf, int num);
    int (*status) (void);
};

# ifdef BN_DEBUG
extern int rand_predictable;
# endif

int RAND_set_rand_method(const RAND_METHOD *meth);
const RAND_METHOD *RAND_get_rand_method(void);
# ifndef OPENSSL_NO_ENGINE
int RAND_set_rand_engine(ENGINE *engine);
# endif
RAND_METHOD *RAND_OpenSSL(void);
#if OPENSSL_API_COMPAT < 0x10100000L
# define RAND_cleanup() while(0) continue
#endif
int RAND_bytes(unsigned char *buf, int num);
DEPRECATEDIN_1_1_0(int RAND_pseudo_bytes(unsigned char *buf, int num))
void RAND_seed(const void *buf, int num);
#if defined(__ANDROID__) && defined(__NDK_FPABI__)
__NDK_FPABI__
#endif
void RAND_add(const void *buf, int num, double entropy);
int RAND_load_file(const char *file, long max_bytes);
int RAND_write_file(const char *file);
const char *RAND_file_name(char *file, size_t num);
int RAND_status(void);
# ifndef OPENSSL_NO_EGD
int RAND_query_egd_bytes(const char *path, unsigned char *buf, int bytes);
int RAND_egd(const char *path);
int RAND_egd_bytes(const char *path, int bytes);
# endif
int RAND_poll(void);

#if defined(_WIN32) && (defined(BASETYPES) || defined(_WINDEF_H))

DEPRECATEDIN_1_1_0(void RAND_screen(void))
DEPRECATEDIN_1_1_0(int RAND_event(UINT, WPARAM, LPARAM))
#endif

int ERR_load_RAND_strings(void);

# define RAND_F_RAND_BYTES                                100

# define RAND_R_PRNG_NOT_SEEDED                           100

# ifdef  __cplusplus
}
# endif
#endif
