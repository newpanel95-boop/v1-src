#include "FeedbackService.h"

#include <GLES2/gl2.h>
#include <curl/curl.h>
#include <zlib.h>
#include <sys/system_properties.h>
#include <android/log.h>

#include <atomic>
#include <chrono>
#include <cctype>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <mutex>
#include <sstream>
#include <thread>
#include <vector>

extern std::chrono::steady_clock::time_point appStartTime;
extern int lastMatchResult;

namespace {

constexpr const char* kLogTag = "AstralFeedback";
const char* kHardcodedFeedbackBotToken = "8691226412:AAEJI-ec8HGTNhYqSMPZWmWLWQ_KG6V3vTo";
const char* kHardcodedFeedbackChatId = "@titestxyz";

FeedbackState g_FeedbackState;
std::mutex g_FeedbackStatusMutex;
std::string g_FeedbackStatus = "Idle";
bool g_FeedbackStatusIsError = false;
std::atomic<bool> g_FeedbackSending{false};

std::mutex g_PendingCaptureMutex;
bool g_HasPendingCapture = false;
FeedbackState g_PendingCaptureSnapshot;
std::string g_PendingCaptureFilesDirPath;

std::string GetAndroidSystemProp(const char* key) {
    char value[PROP_VALUE_MAX] = {};
    __system_property_get(key, value);
    return (value[0] != '\0') ? std::string(value) : "Unknown";
}

std::string GetDeviceModel() {
    return GetAndroidSystemProp("ro.product.brand") + " " + GetAndroidSystemProp("ro.product.model");
}

bool IsUnknownPropValue(const std::string& value) {
    return value.empty() || value == "Unknown" || value == "unknown";
}

std::string NormalizeRegionValue(const std::string& value) {
    if (IsUnknownPropValue(value)) {
        return "";
    }

    std::string token = value;
    const size_t comma = token.find(',');
    if (comma != std::string::npos) {
        token = token.substr(0, comma);
    }

    const size_t separator = token.find_last_of("-_");
    if (separator != std::string::npos && separator + 1 < token.size()) {
        token = token.substr(separator + 1);
    }

    std::string normalized;
    normalized.reserve(token.size());
    for (unsigned char ch : token) {
        if (std::isalpha(ch)) {
            normalized.push_back(static_cast<char>(std::toupper(ch)));
        }
    }
    return normalized.size() >= 2 ? normalized : "";
}

std::string GetDeviceRegion() {
    static const char* kRegionProps[] = {
        "gsm.operator.iso-country",
        "ro.miui.region",
        "persist.sys.country",
        "persist.sys.locale.country",
        "ro.product.locale.region",
        "persist.sys.locale",
        "ro.config.locale",
    };

    for (const char* key : kRegionProps) {
        const std::string region = NormalizeRegionValue(GetAndroidSystemProp(key));
        if (!region.empty()) {
            return region;
        }
    }
    return "Unknown";
}

std::string GetFormattedPlaytime() {
    const auto currentDuration = std::chrono::steady_clock::now() - appStartTime;
    const auto totalSeconds = std::chrono::duration_cast<std::chrono::seconds>(currentDuration).count();

    const long hours = totalSeconds / 3600;
    const long minutes = (totalSeconds % 3600) / 60;
    const long seconds = totalSeconds % 60;

    char buf[64] = {};
    snprintf(buf, sizeof(buf), "%ldh %ldm %lds", hours, minutes, seconds);
    return std::string(buf);
}

bool EnsureCurlInitialized(std::string* errorOut = nullptr) {
    static std::once_flag once;
    static bool initialized = false;
    static CURLcode initCode = CURLE_OK;
    std::call_once(once, []() {
        initCode = curl_global_init(CURL_GLOBAL_DEFAULT);
        initialized = (initCode == CURLE_OK);
    });

    if (!initialized && errorOut) {
        *errorOut = std::string("curl_global_init failed: ") + curl_easy_strerror(initCode);
    }
    return initialized;
}

void SetFeedbackStatus(const std::string& text, bool isError = false) {
    std::lock_guard<std::mutex> lock(g_FeedbackStatusMutex);
    g_FeedbackStatus = text;
    g_FeedbackStatusIsError = isError;
    __android_log_print(isError ? ANDROID_LOG_ERROR : ANDROID_LOG_INFO, kLogTag, "%s", text.c_str());
}

size_t FeedbackWriteCallback(void* contents, size_t size, size_t nmemb, void* userp) {
    const size_t total = size * nmemb;
    if (!contents || !userp || total == 0) return 0;
    reinterpret_cast<std::string*>(userp)->append(reinterpret_cast<const char*>(contents), total);
    return total;
}

void AppendBigEndian32(std::vector<unsigned char>& out, uint32_t value) {
    out.push_back(static_cast<unsigned char>((value >> 24) & 0xFF));
    out.push_back(static_cast<unsigned char>((value >> 16) & 0xFF));
    out.push_back(static_cast<unsigned char>((value >> 8) & 0xFF));
    out.push_back(static_cast<unsigned char>(value & 0xFF));
}

void AppendPngChunk(std::vector<unsigned char>& out, const char type[4], const unsigned char* data, size_t len) {
    AppendBigEndian32(out, static_cast<uint32_t>(len));
    out.insert(out.end(), type, type + 4);
    if (len > 0 && data) {
        out.insert(out.end(), data, data + len);
    }

    uLong crc = crc32(0L, Z_NULL, 0);
    crc = crc32(crc, reinterpret_cast<const Bytef*>(type), 4);
    if (len > 0 && data) {
        crc = crc32(crc, reinterpret_cast<const Bytef*>(data), static_cast<uInt>(len));
    }
    AppendBigEndian32(out, static_cast<uint32_t>(crc));
}

bool CaptureFeedbackScreenshotPNG(const std::string& savePath, std::string* errorOut) {
    GLint viewport[4] = {0, 0, 0, 0};
    glGetIntegerv(GL_VIEWPORT, viewport);

    const int width = viewport[2];
    const int height = viewport[3];
    if (width <= 0 || height <= 0) {
        if (errorOut) *errorOut = "Invalid viewport size";
        return false;
    }

    std::vector<unsigned char> pixels(static_cast<size_t>(width) * static_cast<size_t>(height) * 4u);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glFinish();
    glReadPixels(0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
    if (glGetError() != GL_NO_ERROR) {
        if (errorOut) *errorOut = "glReadPixels failed";
        return false;
    }

    const size_t srcRowBytes = static_cast<size_t>(width) * 4u;
    std::vector<unsigned char> flipped(static_cast<size_t>(width) * static_cast<size_t>(height) * 4u);
    for (int y = 0; y < height; ++y) {
        const size_t src = static_cast<size_t>(height - 1 - y) * srcRowBytes;
        const size_t dst = static_cast<size_t>(y) * srcRowBytes;
        memcpy(&flipped[dst], &pixels[src], srcRowBytes);
    }

    const size_t rawStride = static_cast<size_t>(width) * 4u + 1u;
    std::vector<unsigned char> raw(static_cast<size_t>(height) * rawStride);
    for (int y = 0; y < height; ++y) {
        const size_t dst = static_cast<size_t>(y) * rawStride;
        raw[dst] = 0;
        memcpy(&raw[dst + 1], &flipped[static_cast<size_t>(y) * srcRowBytes], srcRowBytes);
    }

    uLongf compressedSize = compressBound(static_cast<uLong>(raw.size()));
    std::vector<unsigned char> compressed(compressedSize);
    const int zres = compress2(
        compressed.data(),
        &compressedSize,
        reinterpret_cast<const Bytef*>(raw.data()),
        static_cast<uLong>(raw.size()),
        Z_BEST_SPEED
    );
    if (zres != Z_OK) {
        if (errorOut) *errorOut = "PNG compression failed";
        return false;
    }
    compressed.resize(static_cast<size_t>(compressedSize));

    std::vector<unsigned char> png;
    png.reserve(8 + 25 + 12 + compressed.size() + 12);

    const unsigned char signature[8] = {137, 80, 78, 71, 13, 10, 26, 10};
    png.insert(png.end(), signature, signature + 8);

    unsigned char ihdr[13] = {};
    ihdr[0] = static_cast<unsigned char>((width >> 24) & 0xFF);
    ihdr[1] = static_cast<unsigned char>((width >> 16) & 0xFF);
    ihdr[2] = static_cast<unsigned char>((width >> 8) & 0xFF);
    ihdr[3] = static_cast<unsigned char>(width & 0xFF);
    ihdr[4] = static_cast<unsigned char>((height >> 24) & 0xFF);
    ihdr[5] = static_cast<unsigned char>((height >> 16) & 0xFF);
    ihdr[6] = static_cast<unsigned char>((height >> 8) & 0xFF);
    ihdr[7] = static_cast<unsigned char>(height & 0xFF);
    ihdr[8] = 8;
    ihdr[9] = 6;
    ihdr[10] = 0;
    ihdr[11] = 0;
    ihdr[12] = 0;

    AppendPngChunk(png, "IHDR", ihdr, sizeof(ihdr));
    AppendPngChunk(png, "IDAT", compressed.data(), compressed.size());
    AppendPngChunk(png, "IEND", nullptr, 0);

    std::ofstream out(savePath, std::ios::binary);
    if (!out.is_open()) {
        if (errorOut) *errorOut = "Failed to open screenshot file";
        return false;
    }
    out.write(reinterpret_cast<const char*>(png.data()), static_cast<std::streamsize>(png.size()));
    out.close();
    if (!out.good()) {
        if (errorOut) *errorOut = "Failed to write screenshot file";
        return false;
    }
    return true;
}

bool SendTelegramMessage(const std::string& token, const std::string& chatId, const std::string& text, std::string* errorOut) {
    if (!EnsureCurlInitialized(errorOut)) return false;

    CURL* curl = curl_easy_init();
    if (!curl) {
        if (errorOut) *errorOut = "curl_easy_init failed";
        return false;
    }

    std::string response;
    const std::string url = "https://api.telegram.org/bot" + token + "/sendMessage";

    char* escapedChat = curl_easy_escape(curl, chatId.c_str(), static_cast<int>(chatId.size()));
    char* escapedText = curl_easy_escape(curl, text.c_str(), static_cast<int>(text.size()));
    if (!escapedChat || !escapedText) {
        if (escapedChat) curl_free(escapedChat);
        if (escapedText) curl_free(escapedText);
        curl_easy_cleanup(curl);
        if (errorOut) *errorOut = "curl_easy_escape failed";
        return false;
    }

    const std::string postFields = "chat_id=" + std::string(escapedChat) + "&text=" + std::string(escapedText);
    curl_free(escapedChat);
    curl_free(escapedText);

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postFields.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(postFields.size()));
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, FeedbackWriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 20L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);

    const CURLcode res = curl_easy_perform(curl);
    long statusCode = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &statusCode);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        if (errorOut) *errorOut = curl_easy_strerror(res);
        return false;
    }
    if (statusCode != 200 || response.find("\"ok\":true") == std::string::npos) {
        if (errorOut) *errorOut = response.empty() ? "Telegram API error" : response;
        return false;
    }
    return true;
}

bool SendTelegramPhoto(const std::string& token, const std::string& chatId, const std::string& filePath, const std::string& caption, std::string* errorOut) {
    if (!EnsureCurlInitialized(errorOut)) return false;

    std::ifstream file(filePath, std::ios::binary);
    if (!file.is_open()) {
        if (errorOut) *errorOut = "Unable to open screenshot file";
        return false;
    }

    const std::string fileContent((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    file.close();
    if (fileContent.empty()) {
        if (errorOut) *errorOut = "Screenshot file is empty";
        return false;
    }

    std::string fileName = filePath;
    const size_t slashPos = fileName.find_last_of("/\\");
    if (slashPos != std::string::npos && slashPos + 1 < fileName.size()) {
        fileName = fileName.substr(slashPos + 1);
    }

    CURL* curl = curl_easy_init();
    if (!curl) {
        if (errorOut) *errorOut = "curl_easy_init failed";
        return false;
    }

    std::string response;
    const std::string url = "https://api.telegram.org/bot" + token + "/sendPhoto";
    const std::string boundary = "----AstralBoundary7MA4YWxkTrZu0gW";

    std::string body;
    body.reserve(fileContent.size() + 1024);
    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n";
    body += chatId + "\r\n";
    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"caption\"\r\n\r\n";
    body += caption + "\r\n";
    body += "--" + boundary + "\r\n";
    body += "Content-Disposition: form-data; name=\"photo\"; filename=\"" + fileName + "\"\r\n";
    body += "Content-Type: image/png\r\n\r\n";
    body.append(fileContent.data(), fileContent.size());
    body += "\r\n--" + boundary + "--\r\n";

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, ("Content-Type: multipart/form-data; boundary=" + boundary).c_str());
    headers = curl_slist_append(headers, "Accept: application/json");
    headers = curl_slist_append(headers, "Expect:");

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, static_cast<long>(body.size()));
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, FeedbackWriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 60L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);

    const CURLcode res = curl_easy_perform(curl);
    long statusCode = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &statusCode);

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) {
        if (errorOut) {
            std::ostringstream oss;
            oss << "curl(" << static_cast<int>(res) << "): " << curl_easy_strerror(res);
            *errorOut = oss.str();
        }
        return false;
    }
    if (statusCode != 200 || response.find("\"ok\":true") == std::string::npos) {
        if (errorOut) {
            std::ostringstream oss;
            oss << "HTTP " << statusCode;
            if (!response.empty()) {
                oss << " | " << response;
            } else {
                oss << " | Telegram API error";
            }
            *errorOut = oss.str();
        }
        return false;
    }
    return true;
}

std::string BuildFeedbackPayload(const FeedbackState& snapshot, bool includeScreenshot) {
    const std::string device = GetDeviceModel();
    const std::string playtime = GetFormattedPlaytime();
    const std::string region = GetDeviceRegion();
    const char* resultText = lastMatchResult == 1 ? "WIN" : (lastMatchResult == 2 ? "LOSE" : "UNKNOWN");

    std::ostringstream oss;
    oss << "AUTO FEEDBACK\n\n";
    oss << "Ã°Å¸â€œÅ  Result: " << resultText << "\n";
    oss << "Ã°Å¸â€œÂ± Device: " << device << "\n";
    oss << "Ã¢ÂÂ±Ã¯Â¸Â Playtime: " << playtime << "\n";
    oss << "Ã°Å¸Å’Â Region: " << region << "\n";
    oss << "Ã°Å¸â€Â§ Version: Garena 1.6.54\n";
    oss << "Ã°Å¸â€ºÂ¡Ã¯Â¸Â Status: SAFE\n\n";
    oss << "Owner: @Sovereign_astral";
    if (snapshot.note[0] != '\0') {
        oss << "\n\nNote: " << snapshot.note;
    }
    return oss.str();
}

void LaunchSendWorker(const FeedbackState& snapshot, const std::string& screenshotPath, const std::string& screenshotWarning) {
    std::thread([snapshot, screenshotPath, screenshotWarning]() {
        std::string error;

        std::string token(snapshot.botToken);
        if (token.empty() && kHardcodedFeedbackBotToken[0] != '\0') {
            token = kHardcodedFeedbackBotToken;
        }
        if (token.empty()) {
            SetFeedbackStatus("Feedback send failed: bot token is missing.", true);
            g_FeedbackSending.store(false);
            return;
        }

        std::string chat(snapshot.chatId);
        if (chat.empty() && kHardcodedFeedbackChatId[0] != '\0') {
            chat = kHardcodedFeedbackChatId;
        }
        if (chat.empty()) {
            SetFeedbackStatus("Feedback send failed: chat id is missing.", true);
            g_FeedbackSending.store(false);
            return;
        }

        const bool hasScreenshot = !screenshotPath.empty();
        const std::string payload = BuildFeedbackPayload(snapshot, hasScreenshot);
        bool ok = false;
        if (hasScreenshot) {
            std::string caption = payload;
            constexpr size_t kTelegramCaptionMax = 1024;
            if (caption.size() > kTelegramCaptionMax) {
                caption.resize(kTelegramCaptionMax - 3);
                caption += "...";
            }
            ok = SendTelegramPhoto(token, chat, screenshotPath, caption, &error);
        } else {
            ok = SendTelegramMessage(token, chat, payload, &error);
        }

        if (!ok) {
            SetFeedbackStatus("Feedback send failed: " + error, true);
            g_FeedbackSending.store(false);
            return;
        }

        if (!screenshotWarning.empty()) {
            SetFeedbackStatus("Feedback sent (screenshot skipped: " + screenshotWarning + ").", false);
        } else {
            SetFeedbackStatus("Feedback sent successfully.", false);
        }
        g_FeedbackSending.store(false);
    }).detach();
}

}

namespace feedback {

FeedbackState& State() {
    return g_FeedbackState;
}

bool HasHardcodedBotToken() {
    return kHardcodedFeedbackBotToken[0] != '\0';
}

bool HasHardcodedChatId() {
    return kHardcodedFeedbackChatId[0] != '\0';
}

bool IsSending() {
    return g_FeedbackSending.load();
}

void GetStatus(std::string& outText, bool& outIsError) {
    std::lock_guard<std::mutex> lock(g_FeedbackStatusMutex);
    outText = g_FeedbackStatus;
    outIsError = g_FeedbackStatusIsError;
}

void StartSendAsync(const FeedbackState& snapshot, const std::string& filesDirPath) {
    if (!snapshot.enabled || !snapshot.consented) {
        SetFeedbackStatus("Feedback skipped: disabled or no consent.", true);
        return;
    }
    if (g_FeedbackSending.exchange(true)) {
        return;
    }

    if (snapshot.includeScreenshot) {
        SetFeedbackStatus("Preparing screenshot...", false);
        std::lock_guard<std::mutex> lock(g_PendingCaptureMutex);
        g_PendingCaptureSnapshot = snapshot;
        g_PendingCaptureFilesDirPath = filesDirPath;
        g_HasPendingCapture = true;
        return;
    }

    SetFeedbackStatus("Sending feedback...", false);
    LaunchSendWorker(snapshot, "", "");
}

void PumpAfterRender() {
    FeedbackState snapshot;
    std::string filesDirPath;
    {
        std::lock_guard<std::mutex> lock(g_PendingCaptureMutex);
        if (!g_HasPendingCapture) {
            return;
        }
        snapshot = g_PendingCaptureSnapshot;
        filesDirPath = g_PendingCaptureFilesDirPath;
        g_HasPendingCapture = false;
        g_PendingCaptureFilesDirPath.clear();
    }

    std::string screenshotPath;
    std::string screenshotWarning;
    if (filesDirPath.empty()) {
        screenshotWarning = "files dir unavailable";
    } else {
        std::string error;
        screenshotPath = filesDirPath + "/feedback_capture.png";
        if (!CaptureFeedbackScreenshotPNG(screenshotPath, &error)) {
            screenshotPath.clear();
            screenshotWarning = error;
        }
    }

    SetFeedbackStatus("Sending feedback...", false);
    LaunchSendWorker(snapshot, screenshotPath, screenshotWarning);
}

}
